package com.ch.dcs.sync.client.util;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.client.rest.SyncRestTemplate;

import java.util.Map;
import java.util.Set;

public abstract class RestTemplateUtils {

    private static class SingletonRestTemplate {
        static final SyncRestTemplate INSTANCE = new SyncRestTemplate();
    }

    private RestTemplateUtils() {
    }

    public static SyncRestTemplate getInstance() {
        return SingletonRestTemplate.INSTANCE;
    }

    public static <T> T post(String url, Map<String, Object> params, Map<String, String> versionIds,
                             Set<VersionType> versionTypes, Class<T> responseType, Object... uriVariables) {
        return getInstance().post(url, params, versionIds, versionTypes, responseType, uriVariables);
    }

    public static <T> T get(String url, Map<String, Object> params, Class<T> responseType, Object... uriVariables) {
        return getInstance().get(url, params, responseType, uriVariables);
    }
}
