package com.ch.dcs.sync.client.client;

import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.api.service.IVersionSync;
import com.ch.dcs.sync.client.util.RestTemplateUtils;
import com.ch.dcs.sync.model.SyncDemand;
import com.ch.dcs.sync.model.PullRequest;
import com.ch.dcs.sync.model.VersionEntities;
import com.ch.dcs.sync.util.KryoUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ClientVersionService implements IVersionSync {

    private static final Logger LOG = LoggerFactory.getLogger(ClientVersionService.class);

    @Value("${sync.server.host:http://localhost:9000/sync/}")
    private String url;

    @Override
    public List<VersionData> pull(List<SyncDemand> requestList, Long batchSize) {
        String requestUrl = url + "pull?batchSize={batchSize}";
        try {
            String request = KryoUtil.writeToString(new PullRequest(requestList));
            String code = RestTemplateUtils.getInstance().postForObject(requestUrl, request, String.class, batchSize);
            VersionEntities response = KryoUtil.readObjectFromString(code, VersionEntities.class);
            return response.getVersionDataList();
        } catch (Throwable e) {
            LOG.error(String.format("pull data error. url[%s]", requestUrl), e);
        }
        return new ArrayList<>();
    }

    @Override
    public Map<String, Boolean> push(List<VersionData> versionDataList) {
        String requestUrl = url + "push";
        try {
            // ParameterizedTypeReference<Map<String, Boolean>> typeRef = new ParameterizedTypeReference<Map<String, Boolean>>() { };
            // HttpEntity<List<VersionData>> request = new HttpEntity<>(versionDataList);
            // Map<String, Long> uriVariables = new HashMap<>();
            // return RestTemplateUtils.getInstance().exchange(url + "push", HttpMethod.POST, request, typeRef, uriVariables).getBody();
            String request = KryoUtil.writeToString(new VersionEntities(versionDataList));
            String code = RestTemplateUtils.getInstance().postForObject(requestUrl, request, String.class);
            return KryoUtil.readObjectFromString(code, HashMap.class);
        } catch (Throwable e) {
            LOG.error(String.format("push data error. url[%s]", requestUrl), e);
        }
        return new HashMap<>();
    }
}
