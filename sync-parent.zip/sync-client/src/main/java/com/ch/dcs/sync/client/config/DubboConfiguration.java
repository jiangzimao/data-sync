package com.ch.dcs.sync.client.config;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ConsumerConfig;

import com.ch.dcs.sync.config.DubboBaseConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// @Configuration
public class DubboConfiguration extends DubboBaseConfiguration {

    @Value("${sync.consumer.app.name:sync-client-consumer}")
    private String appName;
    @Value("${sync.consumer.config.timeout:5000}")
    private Integer timeout;

    //@Bean
    public ApplicationConfig applicationConfig() {
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName(appName);
        return applicationConfig;
    }

    //@Bean
    public ConsumerConfig consumerConfig() {
        ConsumerConfig consumerConfig = new ConsumerConfig();
        consumerConfig.setTimeout(timeout);
        return consumerConfig;
    }

}
