package com.ch.dcs.sync.client.config;

import com.ch.dcs.sync.config.SyncDataSource;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({SyncDataSource.class})
public class ClientConfig {



}
