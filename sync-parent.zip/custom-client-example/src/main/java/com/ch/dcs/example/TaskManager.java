package com.ch.dcs.example;

import com.ch.dcs.example.provider.UserCustomKeyProvider;
import com.ch.dcs.example.filter.UserEntityFilter;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.client.task.PullTask;
import com.ch.dcs.sync.core.EntityFilter;

import java.util.concurrent.TimeUnit;

public class TaskManager {

    static void start() {

        // 添加用户同步服务端数据定时任务
        registerUserEntityTask();

        // 启动定时推送客户端未提交数据
        PullTask.getInstance().pushStart(1L, 30L, TimeUnit.SECONDS);
    }

    /**
     * 注册同步用户定时任务
     */
    private static void registerUserEntityTask() {
        // 定义数据同步 filter, 此处定义同步旅客数据时，只同步 age > 25 的旅客数据
        EntityFilter userFilter = new UserEntityFilter(25);
        UserCustomKeyProvider userCustomKey = new UserCustomKeyProvider("sha");
        String versionName = "dcs_user";
        VersionType versionType = VersionType.server;
        Long period = 5L;
        Long timeout = 30L;
        Long batchSize = 10000L;
        Integer taskThreadSize = 1;
        PullTask.getInstance().task(userCustomKey, versionName, versionType, period, timeout, TimeUnit.SECONDS,
                taskThreadSize, batchSize, userFilter);
    }

}
