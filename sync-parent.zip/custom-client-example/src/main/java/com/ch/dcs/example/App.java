package com.ch.dcs.example;

import com.ch.dcs.sync.Sync;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Import({Sync.class})
@SpringBootApplication(scanBasePackages = "com.ch.dcs.example")
@EnableJpaRepositories("com.ch.dcs.example.repository")
@EntityScan("com.ch.dcs.example.entity")
public class App {

    public static void main( String[] args ) {
        // 启动服务
        SpringApplication.run(App.class);
        // 启动客户端数据同步定时任务
        TaskManager.start();
    }
}
