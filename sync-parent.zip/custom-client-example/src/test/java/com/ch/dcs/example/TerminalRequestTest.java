package com.ch.dcs.example;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.client.SyncClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class TerminalRequestTest {

    private static final Logger LOG = LoggerFactory.getLogger(TerminalRequestTest.class);

    @Test
    public void postTest() throws Exception {
        int index = 1;
        int count = 0;
        boolean up = true;
        while (true) {
            count++;
            System.out.println("===============" + (count > 4 && index <= 15 ? up ? index++ : index-- : index) + "==============");
            if(count > 4) {
                count = 0;
            }
            if(index == 1) {
                up = true;
            }
            if(index >= 16) {
                up = false;
            }
            CountDownLatch latch = new CountDownLatch(1);
            for (int i = 0; i < index; i++) {
                String[] urls = new String[] {"http://localhost:9000/user/test"};
                for(String url : urls) {
                    new Thread(() -> {
                        Map<String, String> versionIds = new HashMap<>();
                        versionIds.put("dcs_user", "sha");
                        Long startTime = System.currentTimeMillis();
                        try {
                            latch.await();
                        } catch (Exception e) {
                            LOG.error(e.getMessage(), e);
                        }
                        Set<VersionType> versionTypeSet = new HashSet<>();
                        versionTypeSet.add(VersionType.server);
                        if(url.contains("9001")){
                            versionTypeSet.add(VersionType.client);
                        }
                        String res = SyncClient.request(url, null, RequestMethod.POST, versionIds, versionTypeSet);
                        System.out.println(String.format("time:%s ms -- %s", (System.currentTimeMillis() - startTime), res));
                    }).start();
                }
            }
            latch.countDown();
            TimeUnit.SECONDS.sleep(5);
        }
    }

}
