package com.ch.dcs.sync.core;

public abstract class EntityFilter<T> {

    public abstract Boolean filter(T entity);

}
