package com.ch.dcs.sync.service.impl;

import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.cache.DefaultSyncCache;
import com.ch.dcs.sync.cache.ISyncCache;
import com.ch.dcs.sync.core.EntityFilter;
import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.core.VersionCheck;
import com.ch.dcs.sync.core.VersionControl;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.ex.SyncException;
import com.ch.dcs.sync.model.SyncDemand;
import com.ch.dcs.sync.service.IDataMerge;
import com.ch.dcs.sync.service.IDataProvision;
import com.ch.dcs.sync.service.IVersionService;
import com.ch.dcs.sync.util.EntityUtil;
import com.ch.dcs.sync.util.JvmLock;
import com.ch.dcs.sync.util.KeyUtil;
import com.ch.dcs.sync.util.SyncLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
public class VersionService implements IVersionService {

    private static final Logger LOG = LoggerFactory.getLogger(VersionService.class);

    @Autowired
    private ISyncCache syncCache;
    @Autowired
    private IDataProvision dataProvision;
    @Autowired
    private IDataMerge dataMerge;
    @Autowired
    private VersionCheck versionCheck;

    @Override
    public String getBuildId(String versionId, VersionType versionType, Boolean init) {
        return syncCache.getBuildId(versionId, versionType, init);
    }

    @Override
    public Double getNextVersion(String versionKey) {
        return syncCache.getNextVersion(versionKey);
    }

    @Override
    public Double getMaxVersion(VersionType versionType, String buildId, String versionId) {
        Double version = syncCache.getMaxVersion(versionType, buildId, versionId);
        if (version == null) {
            version = 0D;
        }
        return version;
    }

    @Override
    public void saveEntity(VersionEntity entity) {
        if (syncCache instanceof DefaultSyncCache) {
            String versionEntityLock = String.format("ve_lock_%s", entity.getBizKey());
            if (SyncLock.getInstance().tryLock(versionEntityLock, 60, 70, TimeUnit.SECONDS)) {
                try {
                    syncCache.saveVersionEntity(entity);
                } finally {
                    SyncLock.getInstance().unLock(versionEntityLock);
                }
            } else {
                throw new SyncException(String.format("save version entity error. try lock %s return false.",
                        versionEntityLock));
            }
        } else {
            syncCache.saveVersionEntity(entity);
        }
    }

    @Override
    public VersionEntity getEntity(String versionId, VersionType versionType, String bizKey) {
        String buildId = getBuildId(versionId, versionType, false);
        if (buildId == null || "".equals(buildId.trim())) {
            return null;
        }
        String entityKey = KeyUtil.getEntityKey(buildId, versionId, versionType, bizKey);
        return syncCache.getVersionEntity(entityKey);
    }

    @Override
    public Double getVersion(VersionType versionType, String versionId, String bizKey) {
        return syncCache.getVersion(KeyUtil.getSortedKey(versionId, versionType), bizKey);
    }

    @Override
    public List<VersionEntity> sub(VersionType versionType, String versionId, Double start, Boolean includeStart, Double end,
                                   Boolean includeEne) {
        return syncCache.sub(KeyUtil.getSortedKey(versionId, versionType), start, includeStart, end, includeEne);
    }

    @Override
    public void createBuildId(String versionId, String buildId, VersionType versionType) {
        syncCache.createBuildId(versionId, buildId, versionType);
    }

    @Override
    public List<VersionEntity> findAllByType(VersionType type) {
        return syncCache.findAllByType(type);
    }

    @Override
    public Boolean updateTypeByBizKey(VersionType server, String entityKey) {
        return syncCache.updateTypeByBizKey(entityKey, server);
    }

    /**
     * 处理客户端拉取版本信息
     *
     * @param demandList 拉取版本需求
     * @param batchSize  批次数量
     * @return 满足需求的版本数据
     */
    public List<VersionData> pull(List<SyncDemand> demandList, Long batchSize) {
        List<VersionData> result = new ArrayList<>();
        for (SyncDemand syncDemand : demandList) {
            String buildId = syncDemand.getBuildId();
            String versionId = String.format("%s:%s", syncDemand.getVersionName(), syncDemand.getCustomKey());
            if (syncDemand.getSubmit() != null) {
                // 获取 submit 版本数据
                List<VersionData> versionDataList = getVersionData(buildId, versionId, VersionType.server,
                        syncDemand.getSubmit(), batchSize, syncDemand.getEntityFilter());
                if (versionDataList.size() > 0) {
                    result.addAll(versionDataList);
                    if (batchSize > 0 && result.size() >= batchSize) {
                        return result;
                    }
                    // 如果取到versionId 对应的 submit 版本数据，则本次不取其 local 的版本数据
                    continue;
                }
            }
            if (syncDemand.getLocal() != null) {
                // 获取 local 版本数据
                List<VersionData> versionDataList = getVersionData(buildId, versionId, VersionType.client,
                        syncDemand.getLocal(), batchSize, syncDemand.getEntityFilter());
                if (versionDataList.size() > 0) {
                    result.addAll(versionDataList);
                    if (batchSize > 0 && result.size() >= batchSize) {
                        return result;
                    }
                }
            }
        }
        return result;
    }

    /**
     * 处理客户端推送的版本信息，处理过程遵循规则如下:
     * <p>
     * <p> 1、提交的版本在服务端不存在，调用业务系统保存该业务数据后，将其纳入到版本控制中
     * <p> 2、提交的版本在服务端存在，则按以下规则处理:
     * <pre>
     *  if (同一客户端提交) {
     *      if (提交的客户端版本号较大) {
     *          调用业务系统保存该业务数据，并更新版本信息
     *      } else {
     *          已存在更高版本，忽略本次提交，直接返回成功
     *      }
     *  } else {
     *      调用业务系统合并数据接口服务进行数据合并，并更新版本信息
     *  }
     * </pre>
     *
     * @param versionDataList 客户端推送版本数据
     * @return Map  每条版本信息处理结果
     */
    @Override
    public Map<String, Boolean> push(List<VersionData> versionDataList) {
        Map<String, Boolean> result = new HashMap<>();
        for (VersionData versionData : versionDataList) {
            // 提交的业务数据
            Object entity = versionData.getEntity();
            // 提交的版本数据
            VersionEntity clientVersionEntity = versionData.getVersionEntity();
            // 版本Key
            String versionId = KeyUtil.getVersionId(entity);
            // 版本大小
            String buildId = versionData.getVersionEntity().getBuildId();
            // 构建版本信息
            createBuildId(versionId, buildId, VersionType.server);
            // 查询是否已存在对应的版本信息
            VersionEntity versionEntity = getEntity(versionId, VersionType.server, clientVersionEntity.getBizKey());
            if (versionEntity != null) {
                // 判断是否同一客户端提交
                if (versionEntity.getAppId().equals(SyncContext.getAppId())) {
                    // 同一个客户端提交，且已存在版本信息，比较版本号
                    if (clientVersionEntity.getLocal() <= versionEntity.getLocal()) {
                        // 已存在更高的版本号，直接返回成功
                        result.put(clientVersionEntity.getBizKey(), Boolean.TRUE);
                        continue;
                    }
                    // 更新业务数据
                    entity = EntityUtil.syncPersist(versionEntity.getBizKey(), entity, en -> dataMerge.upgrade(en));
                } else {
                    // 不同客户端提交，则调用业务系统数据合并接口服务进行数据合并
                    entity = EntityUtil.syncPersist(versionEntity.getBizKey(), entity, en -> dataMerge.merge(en));
                }
            } else {
                // 更新业务数据
                entity = EntityUtil.syncPersist(clientVersionEntity.getBizKey(), entity, en -> dataMerge.upgrade(en));
            }
            VersionControl.submit(entity, buildId, clientVersionEntity.getLocal(), clientVersionEntity.getAppId());
            // entity key : sync:entity:dcs_user:sha:d2b2552d-8275-4616-bfb5-32867163b02e:client:47ff9abb255b4b97b716557055596574
            String entityKey = KeyUtil.getEntityKey(buildId, versionId, clientVersionEntity.getType(), clientVersionEntity.getBizKey());
            result.put(entityKey, Boolean.TRUE);
        }
        return result;
    }

    /**
     * 获取版本数据
     *
     * @param versionId    版本Id
     * @param versionType  版本类型
     * @param startVersion 客户端最新版本
     * @param batchSize    批量拉取的版本数量
     * @param entityFilter 过滤接口
     * @return 版本信息
     */
    private List<VersionData> getVersionData(String buildId, String versionId, VersionType versionType,
                                             Double startVersion, Long batchSize, EntityFilter entityFilter) {
        versionCheck.addCheckVersionKey(versionId);
        // 定义返回结果集
        List<VersionData> versionDataList = new ArrayList<>();
        String serverBuildId = getBuildId(versionId, versionType, false);
        if (serverBuildId == null) {
            return new ArrayList<>();
        } else if (StringUtils.isEmpty(buildId)) {
            buildId = serverBuildId;
        }
        if (!serverBuildId.equals(buildId)) {
            startVersion = 0D;
            buildId = serverBuildId;
        }
        // 获取当前版本号
        Double currentVersion = getMaxVersion(versionType, buildId, versionId);
        // 比对版本号
        if (currentVersion > startVersion) {
            // 服务端当前版本号大于客户端的版本号，则说明服务端产生了新数据，先要确定本次接取的最大版本号
            Double endVersion = startVersion + (batchSize > 0 ? batchSize : currentVersion);
            StringBuilder info = new StringBuilder();
            long startTime = System.currentTimeMillis();
            // 找出符合条件的 versionEntity
            List<VersionEntity> versionEntities = sub(versionType, versionId, startVersion, true, endVersion, true);
            info.append(String.format("sub cost time[%s] size [%s] ", System.currentTimeMillis() - startTime, versionEntities.size()));
            startTime = System.currentTimeMillis();
            for (VersionEntity versionEntity : versionEntities) {
                // 服务端版本号
                Double entityVersion = versionType == VersionType.server ? versionEntity.getSubmit() : versionEntity.getLocal();
                // 比对版本号
                if (entityVersion > startVersion && entityVersion <= endVersion) {
                    // 版本号属于本次拉取的版本号区间，调用业务系统数据提供接口获取对应的业务数据
                    // versionId : dcs_user:sha
                    String[] vis = versionId.split(":");
                    Set<Class<?>> classSet = SyncContext.getClassByName(vis[0]);
                    Object entity = dataProvision.getBizEntityByKey(versionEntity.getBizKey(), classSet);
                    if (entity != null) {
                        if(entityFilter != null && !entityFilter.filter(entity)) {
                            continue;
                        }
                        versionDataList.add(new VersionData(versionEntity, entity));
                    }
                }
            }
            info.append(String.format(" getBizEntityByKey[%s]", System.currentTimeMillis() - startTime));
            System.out.println(info.toString());
        }
        return versionDataList;
    }
}
