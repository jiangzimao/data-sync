package com.ch.dcs.sync.repository;

import com.ch.dcs.sync.entity.SerialEntity;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface SerialRepository extends CrudRepository<SerialEntity, String> {

    SerialEntity findByVersionKey(String versionKey);

    @Transactional
    @Modifying
    @Query("update SerialEntity set number = ?1 where number = ?2 and versionKey = ?3")
    Integer updateNumber(Double newNumber, Double currentNumber, String versionKey);

    @Transactional
    @Modifying
    @Query("update SerialEntity set number = ?1 where number < ?1 and versionKey = ?2")
    Integer updateNumber(Double submit, String versionKey);

    @Transactional
    @Modifying
    @Query("delete from SerialEntity where versionKey = ?1")
    Integer deleteByVersionKey(String versionKey);
}
