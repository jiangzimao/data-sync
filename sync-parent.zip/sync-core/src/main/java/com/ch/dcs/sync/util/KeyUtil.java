package com.ch.dcs.sync.util;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.core.SyncContext;
import org.springframework.util.StringUtils;

public abstract class KeyUtil {

    public static String getEntityKey(String buildId, String versionId, VersionType versionType, String bizKey) {
        String entityPackageKey = getEntityPackageKey(buildId, versionId, versionType);
        return String.format("%s:%s", entityPackageKey, bizKey);
    }

    public static <T> String getVersionId(T entity) {
        // get versionAble type
        Class<?> entityClass = entity.getClass();

        String versionType = SyncContext.getVersionName(entityClass);

        // get custom key
        String customKey = EntityUtil.getCustomKey(entity);

        // versionAble id
        if(customKey == null) {
            return versionType;
        }
        return String.format("%s:%s", versionType, customKey);
    }

    public static String getSortedKey(String versionId, VersionType versionType) {
        return String.format("%s:sorted:%s:%s",
                SyncContext.getRedisPrefix(), versionType.name().toLowerCase(), versionId);
    }

    public static String getBuildKey(String versionId, VersionType versionType) {
        return getBuildMappingKey("build", versionId, versionType);
    }

    public static String getEntityPackageKey(String buildId, String versionId, VersionType versionType) {
        return String.format("%s:entity:%s:%s:%s", SyncContext.getRedisPrefix(), versionId, buildId,
                versionType.name().toLowerCase());
    }

    public static String getVersionKey(VersionType versionType, String buildId, String versionId) {
        if(StringUtils.isEmpty(buildId)) {
            System.out.println("-----------");
        }
        return String.format("%s:version:%s:%s:%s", SyncContext.getRedisPrefix(), versionType.name().toLowerCase(),
                buildId, versionId);
    }

    public static String getBuildMappingKey(String region, String versionId, VersionType versionType) {
        return String.format("%s:%s:%s:%s",
                SyncContext.getRedisPrefix(), region, versionType.name().toLowerCase(), versionId);
    }
}
