package com.ch.dcs.sync.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.time.Duration;

@Configuration
public class SyncRedisConfig {

    @Value("${sync.redis.hostName:localhost}")
    private String hostName;
    @Value("${sync.redis.host:6379}")
    private Integer port;
    @Value("${sync.redis.password:}")
    private String password;
    @Value("${sync.redis.database:0}")
    private Integer database;

    @Bean(name = "syncJedisConnectionFactory")
    public JedisConnectionFactory jedisConnectionFactory() {
        RedisStandaloneConfiguration config = new RedisStandaloneConfiguration();
        config.setHostName(hostName);
        config.setPort(port);
        config.setPassword("".equals(password.trim()) ? RedisPassword.none() : RedisPassword.of(password));
        config.setDatabase(database);
        return new JedisConnectionFactory(config);
    }

    @Bean(name = "syncRedisTemplate")
    public RedisTemplate stringRedisTemplate(@Qualifier("syncJedisConnectionFactory") RedisConnectionFactory factory) {
        RedisTemplate redisTemplate = new StringRedisTemplate();
        redisTemplate.setConnectionFactory(factory);
        return redisTemplate;
    }

}
