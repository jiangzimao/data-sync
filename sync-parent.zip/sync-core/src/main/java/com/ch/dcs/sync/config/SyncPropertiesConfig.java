package com.ch.dcs.sync.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SyncPropertiesConfig {

    @Value("${sync.version.type}")
    protected String versionType;
    @Value("${sync.redis.redis-prefix:sync}")
    protected String redisPrefix;
    @Value("${sync.h2.path:.//h2_database//h2.data;MODE=MySQL;AUTO_SERVER=TRUE}")
    protected String h2Path;
    @Value("${sync.app.id}")
    protected String appId;
    @Value("${sync.db.type:h2}")
    protected String dbType;

    @Value("${sync.datasource.driver-class-name:org.h2.Driver}")
    protected String driverClassName;
    @Value("${sync.datasource.url:jdbc:h2:file:.\\data\\server;MODE=MySQL;AUTO_SERVER=TRUE}")
    protected String url;
    @Value("${sync.datasource.username:sa}")
    protected String username;
    @Value("${sync.datasource.password:sa}")
    protected String password;


}
