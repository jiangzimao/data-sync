package com.ch.dcs.sync.service;

/**
 * merge business data interface
 */
public interface IDataMerge<T> {

    /**
     * merge the business data and return the merged data
     *
     * @param entity business data submitted by the client
     * @return merged business data
     */
    T merge(T entity);

    /**
     * insert or update business data
     *
     * @param entity business data submitted by the client
     * @return upgrade result
     */
     T upgrade(T entity);
}
