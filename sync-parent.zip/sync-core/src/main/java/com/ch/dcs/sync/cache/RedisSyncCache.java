package com.ch.dcs.sync.cache;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.convert.VersionTypeConverter;
import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.ex.SyncException;
import com.ch.dcs.sync.service.IDataProvision;
import com.ch.dcs.sync.util.EntityUtil;
import com.ch.dcs.sync.util.KeyUtil;
import com.ch.dcs.sync.util.RedisLock;
import com.ch.dcs.sync.util.SyncLock;
import org.apache.commons.beanutils.BeanUtilsBean;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisConnectionUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.data.redis.hash.BeanUtilsHashMapper;
import org.springframework.data.redis.hash.HashMapper;
import org.springframework.data.redis.support.atomic.RedisAtomicDouble;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

public class RedisSyncCache extends AbstractSyncCache {

    private HashMapper<VersionEntity, String, String> mapper = new BeanUtilsHashMapper<VersionEntity>(VersionEntity.class){

        @Override
        public VersionEntity fromHash(Map<String, String> hash) {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            if(!convertClassLoaders.contains(classLoader)){
                BeanUtilsBean.getInstance().getConvertUtils().register(new VersionTypeConverter(), VersionType.class);
                convertClassLoaders.add(classLoader);
            }
            return super.fromHash(hash);
        }
    };
    private Map<String, RedisAtomicDouble> versions = new ConcurrentHashMap<>();
    private Set<ClassLoader> convertClassLoaders = new HashSet<>();
    private RedisTemplate<String, String> redisTemplate;
    private ValueOperations<String, String> valueOperations;
    private HashOperations<String, String, String> hashOperations;
    private ZSetOperations<String, String> zsetOperations;

    private RedisSyncCache(IDataProvision dataProvision) {
        super(dataProvision);
    }

    public RedisSyncCache(RedisTemplate<String, String> redisTemplate, IDataProvision dataProvision) {
        this(dataProvision);
        this.redisTemplate = redisTemplate;
        this.valueOperations = redisTemplate.opsForValue();
        this.hashOperations = redisTemplate.opsForHash();
        this.zsetOperations = redisTemplate.opsForZSet();
    }

    @Override
    public String getBuildId(String versionId, VersionType versionType, Boolean init) {
        String buildKey = KeyUtil.getBuildKey(versionId, versionType);
        String buildId = valueOperations.get(buildKey);
        if(init && StringUtils.isEmpty(buildId)) {
            buildId = checkBuildId(versionId, buildKey, buildId, SyncContext.getVersionType());
        }
        return buildId;
    }

    @Override
    public Double getMinVersion(VersionType versionType, String buildId, String versionId) {
        String sortedKey = KeyUtil.getSortedKey(versionId, versionType);
        return getExtremeValue(buildId, versionId, sortedKey, 0, 0);
    }

    @Override
    public Double getMaxVersion(VersionType versionType, String buildId, String versionId) {
        String sortedKey = KeyUtil.getSortedKey(versionId, versionType);
        return getExtremeValue(buildId, versionId, sortedKey, -1, -1);
    }

    @Override
    public Double getNextVersion(String versionKey) {
        Function<String, RedisAtomicDouble> initFun = (key) ->
                new RedisAtomicDouble(key, redisTemplate.getConnectionFactory());
        return versions.computeIfAbsent(versionKey, initFun).incrementAndGet();
    }

    @Override
    public void saveVersionEntity(VersionEntity entity) {
        String entityKey = KeyUtil.getEntityKey(entity.getBuildId(), entity.getVersionId(), entity.getType(), entity.getBizKey());
        Map<String, String> mappedHash = mapper.toHash(entity);
        hashOperations.putAll(entityKey, mappedHash);
        zsetOperations.add(KeyUtil.getSortedKey(entity.getVersionId(), entity.getType()),
                entity.getBizKey(), EntityUtil.getEntityScore(entity));
        if(entity.getType() != SyncContext.getVersionType()) {
            String versionKey = KeyUtil.getVersionKey(entity.getType(), entity.getBuildId(), entity.getVersionId());
            valueOperations.set(versionKey, String.valueOf(EntityUtil.getEntityScore(entity)));
        }
    }

    @Override
    public VersionEntity getVersionEntity(String entityKey) {
        Map<String, String> loadedHash = hashOperations.entries(entityKey);
        if (loadedHash.size() == 0) {
            return null;
        }
        return mapper.fromHash(loadedHash);
    }

    @Override
    public List<VersionEntity> sub(String sortedKey, Double start, Boolean includeStart, Double end, Boolean includeEnd) {
        // StringBuilder log = new StringBuilder();
        long startTime = System.currentTimeMillis();
        Set<String> keys = zsetOperations.rangeByScore(sortedKey, start, end);
        // log.append(String.format("rangeBySore[%s]", System.currentTimeMillis() - startTime));
        startTime = System.currentTimeMillis();
        List<VersionEntity> subList = new ArrayList<>(keys.size());
        // sortedKey : sync:sorted:server:dcs_user:sha
        String[] info = sortedKey.split(":");
        String versionId = String.format("%s:%s", info[3], info[4]);
        VersionType versionType = VersionType.valueOf(info[2]);
        String buildId = getBuildId(versionId, versionType, false);
        // log.append(String.format(" init key[%s]", System.currentTimeMillis() - startTime));
        startTime = System.currentTimeMillis();
        for(String bizKey : keys) {
            String entityKey = KeyUtil.getEntityKey(buildId, versionId, versionType, bizKey);
            VersionEntity entity = getVersionEntity(entityKey);
            if(entity != null) {
                subList.add(entity);
            }
        }
        // log.append(String.format(" getEntityKey[%s]", System.currentTimeMillis() - startTime));
        // System.out.println("====" + log.toString());
        return subList;
    }

    @Override
    public Double getVersion(String sortedKey, String bizKey) {
        return zsetOperations.score(sortedKey, bizKey);
    }

    @Override
    public void createBuildId(String versionId, String buildId, VersionType versionType) {
        String mappingKey = KeyUtil.getBuildMappingKey("mapping", versionId, versionType);
        String buildKey = KeyUtil.getBuildKey(versionId, versionType);
        String oldBuildId = valueOperations.get(mappingKey);
        if(!buildId.equals(oldBuildId)){
            checkBuildId(versionId, buildKey, buildId, versionType);
        }
        valueOperations.set(mappingKey, buildId);
        valueOperations.set(buildKey, buildId);
    }

    @Override
    public List<VersionEntity> findAllByType(VersionType type) {
        RedisConnectionFactory factory = null;
        RedisConnection conn = null;
        try {
            factory = redisTemplate.getConnectionFactory();
            conn = factory.getConnection();
            String pattern = String.format("%s:%s:*:%s:*", SyncContext.getRedisPrefix(), "entity", type);
            Set<byte[]> keys = conn.keys(pattern.getBytes());
            if(keys.size() > 0) {
                return keys.stream().map(entityKey -> {
                    Map<String, String> loadedHash = hashOperations.entries(new String(entityKey));
                    if (loadedHash.size() == 0) {
                        return null;
                    }
                    return mapper.fromHash(loadedHash);
                }).filter(entity -> entity != null && type == entity.getType()).collect(Collectors.toList());
            }
        } finally {
            if(factory != null) {
                RedisConnectionUtils.releaseConnection(conn, factory);
            }
        }
        return new ArrayList<>();
    }

    @Override
    public Boolean updateTypeByBizKey(String entityKey, VersionType type) {
        // delete from hash
        VersionEntity versionEntity = getVersionEntity(entityKey);
        String sortedKey = KeyUtil.getSortedKey(versionEntity.getVersionId(), versionEntity.getType());
        zsetOperations.remove(sortedKey, versionEntity.getBizKey());
        redisTemplate.delete(entityKey);
        return true;
    }

    private String checkBuildId(String versionId, String buildKey, String buildId, VersionType versionType) {
        String lockKey = String.format("build_%s", versionId);
        if(SyncLock.getInstance().tryLock(lockKey, 45, 60, TimeUnit.SECONDS)) {
            try {
                String mappingKey = KeyUtil.getBuildMappingKey("mapping", versionId, versionType);
                String mappingBuildId = valueOperations.get(mappingKey);
                Boolean cleanBuildCache = false;
                if(StringUtils.isEmpty(buildId)) {
                    if(StringUtils.isEmpty(mappingBuildId)){
                        // 说明是新建立
                        cleanBuildCache = true;
                    } else {
                        buildId = mappingBuildId;
                    }
                } else  {
                    // 说明是校验
                    String currentBuildId = valueOperations.get(buildKey);
                    if(!StringUtils.isEmpty(mappingBuildId)
                            && (!mappingBuildId.equals(currentBuildId)
                            || !mappingBuildId.equals(buildId))){
                        // 说明要重建
                        cleanBuildCache = true;
                    }
                }
                if(cleanBuildCache && !StringUtils.isEmpty(mappingBuildId)) {
                    String entityKey = KeyUtil.getEntityPackageKey(mappingBuildId, versionId, versionType);
                    String zsetKey = KeyUtil.getSortedKey(versionId, versionType);
                    Set<String> bizKeys = zsetOperations.range(zsetKey, 0, -1);
                    Set<String> entityKeys = bizKeys.stream().map(bizKey -> String.format("%s:%s", entityKey, bizKey)).collect(Collectors.toSet());
                    redisTemplate.delete(entityKeys);
                    zsetOperations.removeRange(zsetKey, 0, -1);
                    String versionCacheKey = KeyUtil.getVersionKey(versionType, mappingBuildId, versionId);
                    redisTemplate.delete(versionCacheKey);
                }
                buildId = initBuildVersion(versionId, buildId);
                valueOperations.set(mappingKey, buildId);
                valueOperations.set(buildKey, buildId);
            } finally {
                SyncLock.getInstance().unLock(lockKey);
            }
        } else {
            throw new SyncException(String.format("try lock %s result is false.", lockKey));
        }
        return buildId;
    }

    private Double getExtremeValue(String buildId, String versionId, String sortedKey, int start, int end) {
        // sortedKey : sync:sorted:client:dcs_user:sha
        VersionType versionType = VersionType.valueOf(sortedKey.split(":")[2]);
        String versionKey = KeyUtil.getVersionKey(versionType, buildId, versionId);
        Function<String, RedisAtomicDouble> initFun = (key) ->
                new RedisAtomicDouble(key, redisTemplate.getConnectionFactory());
        Double currentVersion = versions.computeIfAbsent(versionKey, initFun).get();
        Set<String> keys = zsetOperations.range(sortedKey, start, end);
        if (keys.size() > 0) {
            return zsetOperations.score(sortedKey, keys.iterator().next());
        }
        return start < 0 ? currentVersion : 0D;
    }
}
