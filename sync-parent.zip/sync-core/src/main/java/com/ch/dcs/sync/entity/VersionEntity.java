package com.ch.dcs.sync.entity;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.model.VersionEntityPk;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@IdClass(VersionEntityPk.class)
@Table(name = "sync_version")
public class VersionEntity implements Serializable {

    @Id
    private String buildId;
    @Id
    private String bizKey;
    @Enumerated(EnumType.STRING)
    private VersionType type;
    private String versionId;
    private String code;
    private Double local = 0D;
    private Double submit = 0D;
    private String appId;

    public VersionEntity() {
    }

    public VersionEntity(String bizKey, String buildId, VersionType type) {
        this.bizKey = bizKey;
        this.buildId = buildId;
        this.type = type;
    }

    public String getVersionId() {
        return versionId;
    }

    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    public String getBizKey() {
        return bizKey;
    }

    public void setBizKey(String bizKey) {
        this.bizKey = bizKey;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Double getLocal() {
        return local;
    }

    public void setLocal(Double local) {
        this.local = local;
    }

    public Double getSubmit() {
        return submit;
    }

    public void setSubmit(Double submit) {
        this.submit = submit;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public VersionType getType() {
        return type;
    }

    public void setType(VersionType type) {
        this.type = type;
    }

    public void setBuildId(String buildId) {
        this.buildId = buildId;
    }

    public String getBuildId() {
        return buildId;
    }

    @Override
    public String toString() {
        return "VersionEntity{" +
                "versionId='" + versionId + '\'' +
                ", bizKey='" + bizKey + '\'' +
                ", code='" + code + '\'' +
                ", local=" + local +
                ", submit=" + submit +
                ", appId='" + appId + '\'' +
                ", type=" + type +
                ", buildId='" + buildId + '\'' +
                '}';
    }
}
