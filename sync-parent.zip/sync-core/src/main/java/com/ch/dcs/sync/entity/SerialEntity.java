package com.ch.dcs.sync.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "sync_serial")
public class SerialEntity implements Serializable {
    @Id
    private String versionKey;
    private Double number;

    public SerialEntity() {
    }

    public SerialEntity(String versionKey, Double number) {
        this();
        this.versionKey = versionKey;
        this.number = number;
    }

    public String getVersionKey() {
        return versionKey;
    }

    public void setVersionKey(String versionKey) {
        this.versionKey = versionKey;
    }

    public Double getNumber() {
        return number;
    }

    public void setNumber(Double number) {
        this.number = number;
    }
}
