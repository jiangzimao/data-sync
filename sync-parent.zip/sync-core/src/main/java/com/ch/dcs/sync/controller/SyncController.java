package com.ch.dcs.sync.controller;

import com.ch.dcs.sync.model.PullRequest;
import com.ch.dcs.sync.model.VersionEntities;
import com.ch.dcs.sync.service.IVersionService;
import com.ch.dcs.sync.util.KryoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sync")
public class SyncController {

    private final IVersionService versionService;

    @Autowired
    public SyncController(IVersionService versionService) {
        this.versionService = versionService;
    }

    @RequestMapping(name = "pull", value = "pull", method = RequestMethod.POST)
    public String pull(@RequestBody String request, Long batchSize){
        PullRequest pullRequest = KryoUtil.readFromString(request);
        return KryoUtil.writeObjectToString(new VersionEntities(versionService.pull(pullRequest.getDemands(), batchSize)));
    }

    @RequestMapping(name = "push", value = "push", method = RequestMethod.POST)
    public String push(@RequestBody String request){
        VersionEntities versionEntities = KryoUtil.readFromString(request);
        return KryoUtil.writeObjectToString(versionService.push(versionEntities.getVersionDataList()));
    }

}
