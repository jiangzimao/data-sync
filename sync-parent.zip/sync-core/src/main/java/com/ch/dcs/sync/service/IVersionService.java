package com.ch.dcs.sync.service;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.api.service.IVersionSync;
import com.ch.dcs.sync.entity.VersionEntity;

import java.util.List;
import java.util.Set;

public interface IVersionService extends IVersionSync {

    String getBuildId(String versionId, VersionType versionType, Boolean init);

    Double getNextVersion(String versionKey);

    Double getMaxVersion(VersionType versionType, String buildId, String versionId);

    void saveEntity(VersionEntity entity);

    VersionEntity getEntity(String versionId, VersionType versionType, String bizKey);

    Double getVersion(VersionType versionType, String versionId, String bizKey);

    List<VersionEntity> sub(VersionType versionType, String versionId, Double start, Boolean includeStart, Double end,
                    Boolean includeEne);

    void createBuildId(String versionId, String buildId, VersionType versionType);

    List<VersionEntity> findAllByType(VersionType type);

    Boolean updateTypeByBizKey(VersionType server, String entityKey);
}
