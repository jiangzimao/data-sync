package com.ch.dcs.sync.api.mode;

import com.ch.dcs.sync.entity.VersionEntity;

import java.io.Serializable;

public class VersionData implements Serializable {

    private VersionEntity versionEntity;
    private Object entity;

    public VersionData() {
    }

    public VersionData(VersionEntity versionEntity, Object entity) {
        this.versionEntity = versionEntity;
        this.entity = entity;
    }

    public VersionEntity getVersionEntity() {
        return versionEntity;
    }

    public void setVersionEntity(VersionEntity versionEntity) {
        this.versionEntity = versionEntity;
    }

    public Object getEntity() {
        return entity;
    }

    public void setEntity(Object entity) {
        this.entity = entity;
    }

    @Override
    public String toString() {
        return "VersionData{" +
                "versionEntity=" + versionEntity +
                ", entity=" + entity +
                '}';
    }
}
