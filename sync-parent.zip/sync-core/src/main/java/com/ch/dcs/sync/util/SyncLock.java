package com.ch.dcs.sync.util;

import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.model.SyncDbType;

import java.util.concurrent.TimeUnit;

public abstract class SyncLock {

    private static SyncLock syncLock;

    public abstract Boolean tryLock(String key, long timeout, long expire, TimeUnit timeUnit);

    public abstract void unLock(String key);

    public static synchronized SyncLock getInstance() {
        if(syncLock == null) {
            SyncDbType dbType = SyncContext.getDbType();
            if(SyncDbType.redis.equals(dbType)) {
                syncLock = new RedisLock();
            } else {
                syncLock = new JvmLock();
            }
        }
        return syncLock;
    }

}
