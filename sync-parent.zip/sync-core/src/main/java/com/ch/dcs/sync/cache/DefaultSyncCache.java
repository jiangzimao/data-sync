package com.ch.dcs.sync.cache;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.entity.BuildEntity;
import com.ch.dcs.sync.entity.MappingEntity;
import com.ch.dcs.sync.entity.SerialEntity;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.ex.SyncException;
import com.ch.dcs.sync.model.VersionEntityPk;
import com.ch.dcs.sync.repository.BuildRepository;
import com.ch.dcs.sync.repository.MappingRepository;
import com.ch.dcs.sync.repository.SerialRepository;
import com.ch.dcs.sync.repository.VersionRepository;
import com.ch.dcs.sync.service.IDataProvision;
import com.ch.dcs.sync.util.JvmLock;
import com.ch.dcs.sync.util.KeyUtil;
import com.ch.dcs.sync.util.SyncLock;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class DefaultSyncCache extends AbstractSyncCache {

    private VersionRepository versionRepository;
    private BuildRepository buildRepository;
    private SerialRepository serialRepository;
    private MappingRepository mappingRepository;

    public DefaultSyncCache(IDataProvision dataProvision) {
        super(dataProvision);
    }

    @Override
    public String getBuildId(String versionId, VersionType versionType, Boolean init) {
        String buildKey = KeyUtil.getBuildKey(versionId, versionType);
        String buildId = buildRepository.getBuildIdByBuildKey(buildKey);
        if(init && StringUtils.isEmpty(buildId)) {
            String lockKey = String.format("lock_%s_%s", versionId, versionType.name());
            if(SyncLock.getInstance().tryLock(lockKey, 45, 0, TimeUnit.SECONDS)) {
                try {
                    buildId = buildRepository.getBuildIdByBuildKey(buildKey);
                    if(StringUtils.isEmpty(buildId)) {
                        Long start = System.currentTimeMillis();
                        buildId = checkBuildId(versionId, buildKey, buildId, SyncContext.getVersionType());
                        log.info(String.format("check build id finish, time is %s ms", (System.currentTimeMillis() - start)));
                    }
                } finally {
                    SyncLock.getInstance().unLock(lockKey);
                }
            } else {
                throw new SyncException(String.format("try lock %s return is false", lockKey));
            }
        }
        return buildId;
    }

    @Override
    public Double getMinVersion(VersionType versionType, String buildId, String versionId) {
        if(versionType == VersionType.client) {
            return versionRepository.getMinLocalVersion(versionId);
        } else {
            return versionRepository.getMinSubmitVersion(versionId);
        }
    }

    @Override
    public Double getMaxVersion(VersionType versionType, String buildId, String versionId) {
        if(versionType == VersionType.client) {
            return versionRepository.getMaxLocalVersion(versionId);
        } else {
            return versionRepository.getMaxSubmitVersion(versionId);
        }
    }

    @Override
    public Double getNextVersion(String versionKey) {
        if(SyncLock.getInstance().tryLock(versionKey, 30, 0, TimeUnit.SECONDS)){
            try {
                SerialEntity serialEntity = serialRepository.findByVersionKey(versionKey);
                Double currentVersion = 1D;
                if(serialEntity == null) {
                    serialEntity = new SerialEntity();
                    serialEntity.setVersionKey(versionKey);
                    serialEntity.setNumber(currentVersion);
                    serialRepository.save(serialEntity);
                    return currentVersion;
                }
                Integer loopCount = 0;
                do {
                    currentVersion = serialEntity.getNumber();
                    serialEntity.setNumber(currentVersion + 1);
                    serialRepository.updateNumber(serialEntity.getNumber(), currentVersion, versionKey);
                    currentVersion = serialRepository.findByVersionKey(versionKey).getNumber();
                    if(currentVersion.equals(serialEntity.getNumber())) {
                        break;
                    }
                } while(loopCount++ < 30);
                if(!currentVersion.equals(serialEntity.getNumber())) {
                    throw new SyncException(String.format("get next version error. update version %s number error.", serialEntity.getVersionKey()));
                }
                return serialEntity.getNumber();
            } finally {
                SyncLock.getInstance().unLock(versionKey);
            }
        }
        throw new SyncException(String.format("gry lock [%s] result is null.", versionKey));
    }

    @Override
    public void saveVersionEntity(VersionEntity entity) {
        versionRepository.save(entity);
        if(entity.getType() != SyncContext.getVersionType()) {
            String versionKey = KeyUtil.getVersionKey(entity.getType(), entity.getBuildId(), entity.getVersionId());
            SerialEntity serialEntity = serialRepository.findByVersionKey(versionKey);
            if(serialEntity == null) {
                serialRepository.save(new SerialEntity(versionKey, entity.getSubmit()));
            } else {
                serialRepository.updateNumber(entity.getSubmit(), versionKey);
            }
        }
    }

    @Override
    public VersionEntity getVersionEntity(String entityKey) {
        if(StringUtils.isEmpty(entityKey)) {
            throw new SyncException("entity key is not null.");
        }
        // sync:entity:dcs_user:sha:d48f6562-548e-44d1-8219-56631ff2b2f9:server:0a6a0250-6952-4157-af66-9320ddef4c7d
        String[] keys = entityKey.split(":");
        return versionRepository.findById(new VersionEntityPk(keys[4], keys[6])).orElse(null);
    }

    @Override
    public List<VersionEntity> sub(String sortedKey, Double start, Boolean includeStart, Double end, Boolean includeEnd) {
        if(StringUtils.isEmpty(sortedKey)) {
            throw new SyncException("sorted key is not null.");
        }
        // sync:sorted:server:dcs_user:sha
        String[] sortedKeys = sortedKey.split(":");
        String versionId = String.format("%s:%s", sortedKeys[3], sortedKeys[4]);
        List<VersionEntity> versionEntityList;
        VersionType versionType= VersionType.client;
        if(VersionType.server.name().equalsIgnoreCase(sortedKeys[2])) {
            versionEntityList = versionRepository.findAllByVersionIdAndSubmitBetween(versionId, start, end);
            versionType = VersionType.server;
        } else {
            versionEntityList = versionRepository.findAllByVersionIdAndLocalBetween(versionId, start, end);
        }
        VersionType finalVersionType = versionType;
        return versionEntityList.stream().filter(versionEntity -> {
            Double version = finalVersionType == VersionType.server ? versionEntity.getSubmit() : versionEntity.getLocal();
            return (includeStart || version > start) && (includeEnd || version < end);
        }).collect(Collectors.toList());
    }

    @Override
    public Double getVersion(String sortedKey, String bizKey) {
        if(StringUtils.isEmpty(sortedKey)) {
            throw new SyncException("sorted key is not null.");
        }
        // sync:sorted:server:dcs_user:sha
        VersionEntity entity = versionRepository.findByBizKey(bizKey);
        if(entity != null) {
            String versionType = sortedKey.split(":")[2];
            if(versionType.equalsIgnoreCase(VersionType.server.name())) {
                return entity.getSubmit();
            }
            return entity.getLocal();
        }
        return 0D;
    }

    @Override
    public void createBuildId(String versionId, String buildId, VersionType versionType) {
        String mappingKey = KeyUtil.getBuildMappingKey("mapping", versionId, versionType);
        String buildKey = KeyUtil.getBuildKey(versionId, versionType);
        String oldBuildId = mappingRepository.getBuildIdByMappingKey(mappingKey);
        if(!buildId.equals(oldBuildId)){
            checkBuildId(versionId, buildKey, buildId, versionType);
        } else {
            refreshBuild(buildId, mappingKey, buildKey);
        }
    }

    @Override
    public List<VersionEntity> findAllByType(VersionType type) {
        return versionRepository.findAllByType(type);
    }

    @Override
    public Boolean updateTypeByBizKey(String entityKey, VersionType type) {
        // sync:entity:dcs_user:sha:d2b2552d-8275-4616-bfb5-32867163b02e:client:47ff9abb255b4b97b716557055596574
        String[] keys = entityKey.split(":");
        VersionEntity versionEntity = versionRepository.findByBizKey(keys[6]);
        if(versionEntity != null) {
            versionEntity.setType(type);
            versionRepository.save(versionEntity);
            return true;
        }
        return false;
    }

    public DefaultSyncCache setVersionRepository(VersionRepository versionRepository) {
        this.versionRepository = versionRepository;
        return this;
    }

    public DefaultSyncCache setBuildRepository(BuildRepository buildRepository) {
        this.buildRepository = buildRepository;
        return this;
    }

    public DefaultSyncCache setSerialRepository(SerialRepository serialRepository) {
        this.serialRepository = serialRepository;
        return this;
    }

    public DefaultSyncCache setMappingRepository(MappingRepository mappingRepository) {
        this.mappingRepository = mappingRepository;
        return this;
    }

    private String checkBuildId(String versionId, String buildKey, String buildId, VersionType versionType) {
        String mappingKey = KeyUtil.getBuildMappingKey("mapping", versionId, versionType);
        String mappingBuildId = mappingRepository.getBuildIdByMappingKey(mappingKey);
        Boolean cleanBuildCache = false;
        if(StringUtils.isEmpty(buildId)) {
            if(StringUtils.isEmpty(mappingBuildId)){
                // 说明是新建立
                cleanBuildCache = true;
            }
        } else  {
            // 说明是校验
            String currentBuildId = buildRepository.getBuildIdByBuildKey(buildKey);
            if(!StringUtils.isEmpty(mappingBuildId)
                    && (!mappingBuildId.equals(currentBuildId)
                    || !mappingBuildId.equals(buildId))){
                // 说明要重建
                cleanBuildCache = true;
            }
        }
        if(cleanBuildCache || (StringUtils.isEmpty(buildId) && !StringUtils.isEmpty(mappingBuildId))) {
            // delete version entity
            versionRepository.deleteByVersionId(versionId);
            if(!StringUtils.isEmpty(mappingBuildId)){
                // delete serial entity
                String versionKey = KeyUtil.getVersionKey(versionType, mappingBuildId, versionId);
                serialRepository.deleteByVersionKey(versionKey);
            }
            // delete mapping entity
            mappingRepository.deleteByMappingKey(mappingKey);
            // delete build entity
            buildRepository.deleteByBuildKey(buildKey);
        }
        buildId = initBuildVersion(versionId, buildId);
        refreshBuild(buildId, mappingKey, buildKey);
        return buildId;
    }

    private void refreshBuild(String buildId, String mappingKey, String buildKey) {
        String lockKey = String.format("%s_%s_%s_refresh_lock", buildId, mappingKey, buildKey);
        if(SyncLock.getInstance().tryLock(lockKey, 2, 0, TimeUnit.MINUTES)) {
            try {
                MappingEntity mappingEntity = mappingRepository.findByMappingKey(mappingKey);
                if(mappingEntity == null) {
                    mappingEntity = new MappingEntity(mappingKey);
                }
                if(!buildId.equals(mappingEntity.getBuildId())) {
                    mappingEntity.setBuildId(buildId);
                    mappingRepository.save(mappingEntity);
                }
                BuildEntity buildEntity = buildRepository.findByBuildKey(buildKey);
                if(buildEntity == null) {
                    buildEntity = new BuildEntity(buildKey);
                }
                if(!buildId.equals(buildEntity.getBuildId())) {
                    buildEntity.setBuildId(buildId);
                    buildRepository.save(buildEntity);
                }
            } finally {
                SyncLock.getInstance().unLock(lockKey);
            }
        } else {
            throw new SyncException(String.format("refresh build error. try lock %s return false.",
                    lockKey));
        }

    }
}
