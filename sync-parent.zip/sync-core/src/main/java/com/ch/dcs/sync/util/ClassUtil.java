package com.ch.dcs.sync.util;

import org.reflections.Reflections;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import sun.reflect.misc.FieldUtil;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public abstract class ClassUtil {

    private static final Map<String, Reflections> REFLECTIONS_MAP = new ConcurrentHashMap<>();

    private static synchronized Reflections getReflections(String packagePath) {
        if (packagePath == null || "".equals(packagePath.trim())) {
            throw new RuntimeException("package path is not null.");
        } else {
            if (!REFLECTIONS_MAP.containsKey(packagePath)) {
                ConfigurationBuilder config = ConfigurationBuilder.build().setUrls(ClasspathHelper.forPackage(packagePath));
                REFLECTIONS_MAP.put(packagePath, new Reflections(config));
            }
            return REFLECTIONS_MAP.get(packagePath);
        }
    }

    public static Set<Class<?>> getClassByAnnotation(String packagePath, Class<? extends Annotation> annotation) {
        if(packagePath == null || "".equals(packagePath.trim())){
            throw new RuntimeException("packagePath is not null.");
        }
        if(annotation == null) {
            throw new RuntimeException("annotation is not null.");
        }
        return getReflections(packagePath).getTypesAnnotatedWith(annotation, true);
    }

    public static List<Field> getFieldsByAnnotation(Class<?> cls, Class<? extends Annotation> annotationClass) {
        if (cls.getSuperclass() != Object.class) {
            return getFieldsByAnnotation(cls.getSuperclass(), annotationClass);
        }
        Field[] fields = FieldUtil.getDeclaredFields(cls);
        List<Field> fieldList = new ArrayList<>();
        for (Field field : fields) {
            if (field.getAnnotation(annotationClass) != null) {
                field.setAccessible(Boolean.TRUE);
                fieldList.add(field);
            }
        }
        return fieldList;
    }

    public static List<Field> getFields(Class<?> cls, Class<? extends Annotation> excludeAnnotationClass) {
        if (cls.getSuperclass() != Object.class) {
            return getFields(cls.getSuperclass(), excludeAnnotationClass);
        }
        Field[] fields = FieldUtil.getDeclaredFields(cls);
        List<Field> fieldList = new ArrayList<>();
        for (Field field : fields) {
            if (field.getAnnotation(excludeAnnotationClass) == null) {
                field.setAccessible(Boolean.TRUE);
                fieldList.add(field);
            }
        }
        return fieldList;
    }

    public static Field getField(Class<?> cla, String fieldName) {
        try {
            return cla.getDeclaredField(fieldName);
        } catch (Exception e) {
            // ignore
        }
        if(!cla.isAssignableFrom(Object.class)){
            return getField(cla.getSuperclass(), fieldName);
        }
        return null;
    }

    public static Field[] getFields(Class<?> cla) {
        Field[] fields = cla.getDeclaredFields();
        if(!cla.getSuperclass().isAssignableFrom(Object.class)) {
            Field[] parentFields = getFields(cla.getSuperclass());
            Field[] newFields = new Field[fields.length + parentFields.length];
            System.arraycopy(parentFields, 0, newFields, 0, parentFields.length);
            System.arraycopy(fields, 0, newFields, parentFields.length, fields.length);
            fields = newFields;
        }
        return fields;
    }
}
