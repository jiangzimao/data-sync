package com.ch.dcs.sync.config;

import com.alibaba.dubbo.config.RegistryConfig;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// @Configuration
public class DubboBaseConfiguration {

    @Value("${sync.dubbo.registry.address:redis://127.0.0.1:6379}")
    private String address;
    @Value("${sync.dubbo.registry.group:dubbo}")
    private String group;
    @Value("${sync.dubbo.registry.client:curator}")
    private String client;

    // @Bean
    public RegistryConfig registryConfig() {
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setAddress(address);
        registryConfig.setGroup(group);
        registryConfig.setClient(client);
        return registryConfig;
    }

}
