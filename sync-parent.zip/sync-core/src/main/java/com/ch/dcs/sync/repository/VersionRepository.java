package com.ch.dcs.sync.repository;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.model.VersionEntityPk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface VersionRepository extends JpaRepository<VersionEntity, VersionEntityPk> {

    @Query("select min(local) from VersionEntity where versionId = ?1")
    Double getMinLocalVersion(String versionId);

    @Query("select min(submit) from VersionEntity where versionId = ?1")
    Double getMinSubmitVersion(String versionId);

    @Query("select max(local) from VersionEntity where versionId = ?1")
    Double getMaxLocalVersion(String versionId);

    @Query("select max(submit) from VersionEntity where versionId = ?1")
    Double getMaxSubmitVersion(String versionId);

    @Transactional
    @Modifying
    @Query("delete from VersionEntity where versionId = ?1")
    void deleteByVersionId(String versionId);

    @Transactional
    @Modifying
    @Query("update VersionEntity set type = ?1 where bizKey = ?2")
    Integer updateTypeByBizKey(VersionType type, String bizKey);

    VersionEntity findByBizKey(String bizKey);

    List<VersionEntity> findAllByVersionIdAndSubmitBetween(String versionId, Double start, Double end);

    List<VersionEntity> findAllByVersionIdAndLocalBetween(String versionId, Double start, Double end);

    List<VersionEntity> findAllByType(VersionType type);
}
