package com.ch.dcs.sync;

import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.core.VersionControl;
import com.ch.dcs.sync.entity.VersionEntity;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

// @DubboComponentScan(basePackages = "com.ch.dcs.sync.api.service")
@SpringBootApplication(scanBasePackages = "com.ch.dcs.sync")
@EnableJpaRepositories("com.ch.dcs.sync.repository")
@EntityScan(basePackages={"com.ch.dcs.sync.entity"})
public abstract class Sync {

    public static ApplicationContext getContext() {
        return SyncContext.getContext();
    }

    public static void versionConfig(String name, String customKey, String bizKey, Class<?> entityClass, String... exclusionFields) {
        SyncContext.registerVersion(name, customKey, bizKey, entityClass, exclusionFields);
    }

    public static <T> VersionEntity submit(T entity){
        return VersionControl.submit(entity);
    }

    public static <T> VersionEntity sync(T entity){
        return VersionControl.sync(entity);
    }
}
