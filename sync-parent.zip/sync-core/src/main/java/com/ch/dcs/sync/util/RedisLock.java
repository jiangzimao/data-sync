package com.ch.dcs.sync.util;

import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.ex.SyncException;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisConnectionUtils;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class RedisLock extends SyncLock {

    private static Cache<String, ReentrantLock> locks = CacheBuilder.newBuilder().expireAfterWrite(12, TimeUnit.HOURS).build();
    private static ThreadLocal<String> threadLock = new ThreadLocal<>();

    public Boolean tryLock(String key, long timeout, long expire, TimeUnit timeUnit) {
        Long timeOut = timeUnit == TimeUnit.SECONDS ? timeout * 1000 : timeout;
        RedisTemplate<String, String> redisTemplate = SyncContext.getBean("syncRedisTemplate", RedisTemplate.class);
        String lockObject = Thread.currentThread().toString();
        Long startTime = System.currentTimeMillis();
        try {
            ReentrantLock lock = locks.get(key, () -> new ReentrantLock(true));
            if(key.equals(threadLock.get())){
                return true;
            }
            if (lock.tryLock(timeout, timeUnit)) {
                threadLock.set(key);
                RedisConnectionFactory factory = null;
                RedisConnection conn = null;
                try {
                    factory = redisTemplate.getConnectionFactory();
                    conn = factory.getConnection();
                    do {
                        if (conn.setNX(getLockKey(key).getBytes(), lockObject.getBytes())) {
                            redisTemplate.expire(getLockKey(key), expire, timeUnit);
                            return true;
                        }
                        // 获取锁失败时，应该在随机延时后进行重试，避免不同客户端同时重试导致谁都无法拿到锁的情况出现
                        // 睡眠 3 毫秒后继续请求锁
                        Thread.sleep(3, new Random().nextInt(500));
                    } while (System.currentTimeMillis() - startTime < timeOut);
                    throw new SyncException(String.format("try lock key[%s] time out.", key));
                } finally {
                    if(factory != null) {
                        RedisConnectionUtils.releaseConnection(conn, factory);
                    }
                    lock.unlock();
                }
            } else {
                throw new SyncException(String.format("try java lock key[%s] result is false.", key));
            }
        } catch (Throwable e) {
            throw new SyncException(String.format("try lock key[%s] error.", key), e);
        }
    }

    public void unLock(String key) {
        for (StackTraceElement element : Thread.currentThread().getStackTrace()) {
            if("tryLock".equals(element.getMethodName()) && RedisLock.class.getName().equals(element.getClassName())) {
                return;
            }
        }
        RedisTemplate redisTemplate = SyncContext.getBean("syncRedisTemplate", RedisTemplate.class);
        RedisConnectionFactory factory = null;
        RedisConnection conn = null;
        try {
            factory = redisTemplate.getConnectionFactory();
            conn = factory.getConnection();
            conn.del(getLockKey(key).getBytes());
        } finally {
            if(factory != null) {
                RedisConnectionUtils.releaseConnection(conn, factory);
            }
        }
    }

    private static String getLockKey(String key) {
        return String.format("%s:lock:lock_%s", SyncContext.getRedisPrefix(), key);
    }

}
