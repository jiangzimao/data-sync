package com.ch.dcs.example.entity;

import java.util.Date;

public class PaxEntity extends UuiEntity {

    private Long lu;
    private String fn;
    private Date fd;
    private String sde;
    private String name;
    private Integer age;

    public PaxEntity(Long lu, String fn, Date fd, String sde, String name, Integer age) {
        this.lu = lu;
        this.fn = fn;
        this.fd = fd;
        this.sde = sde;
        this.name = name;
        this.age = age;
    }

    public Long getLu() {
        return lu;
    }

    public void setLu(Long lu) {
        this.lu = lu;
    }

    public String getFn() {
        return fn;
    }

    public void setFn(String fn) {
        this.fn = fn;
    }

    public Date getFd() {
        return fd;
    }

    public void setFd(Date fd) {
        this.fd = fd;
    }

    public String getSde() {
        return sde;
    }

    public void setSde(String sde) {
        this.sde = sde;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "PaxEntity{" +
                "lu=" + lu +
                ", fn='" + fn + '\'' +
                ", fd=" + fd +
                ", sde='" + sde + '\'' +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
