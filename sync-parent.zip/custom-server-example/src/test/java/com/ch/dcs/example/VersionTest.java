package com.ch.dcs.example;

import com.ch.dcs.example.entity.PaxEntity;
import com.ch.dcs.example.entity.SeatEntity;
import com.ch.dcs.example.entity.UserEntity;
import com.ch.dcs.sync.Sync;
import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.core.VersionControl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class VersionTest {

    @Autowired
    private ApplicationContext context;

    public static Set<Double> versions = new HashSet<>();

    @Test
    public void getVersionTest() throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        int size = 50;
        while (true) {
            size++;
            for (int i = 0; i < size; i++) {
                new Thread(() -> {
                    UserEntity userEntity = new UserEntity("sha", new Random().nextInt(100), new Date());
                    try {
                        latch.await();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    long start = System.currentTimeMillis();
                    VersionEntity userEntityAfter = VersionControl.submit(userEntity);
                    //System.out.println("all time = " + (System.currentTimeMillis() - start) + " ms");
                    Double version = userEntityAfter.getSubmit();
                    if(!versions.add(version)){
                        // throw new RuntimeException(String.format("version %s arady exist.", version));
                    }
                    System.out.println(userEntityAfter);
                }).start();
                latch.countDown();
            }
            TimeUnit.SECONDS.sleep(5);
        }
    }

    @Test
    public void submit() {
        UserEntity userEntity = new UserEntity("sha", new Random().nextInt(100), new Date());
        VersionEntity userEntityAfter = VersionControl.submit(userEntity);
        System.out.println(userEntityAfter);
        userEntity.setAge(34);
        userEntityAfter = VersionControl.submit(userEntity);
        System.out.println(userEntityAfter);
    }

    @Test
    public void add(){
        UserEntity userEntity = new UserEntity("sha", new Random().nextInt(100), new Date());
        Sync.submit(userEntity);
        VersionControl.submit(userEntity);

        // Long lu = System.currentTimeMillis();
        // PaxEntity p1 = new PaxEntity(lu, "9c8877", new Date(), "sha", "name_" + UUID.randomUUID().toString(), new Random().nextInt(50));
        // PaxEntity p2 = new PaxEntity(lu, "9c8877", new Date(), "sha", "name_" + UUID.randomUUID().toString(), new Random().nextInt(50));
        // Sync.submit(p1);
        // Sync.submit(p2);

        // for (int i = 0; i < 30; i++) {
        //     Sync.submit(new SeatEntity(lu, i + 1, "a"));
        // }

    }



}
