package com.ch.dcs.sync.api.service.impl;

import com.ch.dcs.sync.api.service.IVersionSync;
import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.model.SyncDemand;
import com.ch.dcs.sync.service.IVersionService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

@com.alibaba.dubbo.config.annotation.Service
public class VersionSyncImpl implements IVersionSync {

    private final IVersionService versionService;

    @Autowired
    public VersionSyncImpl(IVersionService versionService) {
        this.versionService = versionService;
    }

    /**
     * 处理客户端拉取版本信息
     *
     * @param demandList 拉取版本需求
     * @param batchSize  批次数量
     * @return 满足需求的版本数据
     */
    public List<VersionData> pull(List<SyncDemand> demandList, Long batchSize) {
        return versionService.pull(demandList, batchSize);
    }

    /**
     * 处理客户端推送的版本信息，处理过程遵循规则如下:
     * <p>
     * <p> 1、提交的版本在服务端不存在，调用业务系统保存该业务数据后，将其纳入到版本控制中
     * <p> 2、提交的版本在服务端存在，则按以下规则处理:
     * <pre>
     *  if (同一客户端提交) {
     *      if (提交的客户端版本号较大) {
     *          调用业务系统保存该业务数据，并更新版本信息
     *      } else {
     *          已存在更高版本，忽略本次提交，直接返回成功
     *      }
     *  } else {
     *      调用业务系统合并数据接口服务进行数据合并，并更新版本信息
     *  }
     * </pre>
     *
     * @param versionDataList 客户端推送版本数据
     * @return Map  每条版本信息处理结果
     */
    @Override
    public Map<String, Boolean> push(List<VersionData> versionDataList) {
        return versionService.push(versionDataList);
    }
}
