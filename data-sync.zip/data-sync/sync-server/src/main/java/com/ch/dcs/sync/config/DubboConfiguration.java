package com.ch.dcs.sync.config;

import com.alibaba.dubbo.config.ApplicationConfig;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// @Configuration
public class DubboConfiguration extends DubboBaseConfiguration {

    @Value("${sync.provider.app.name:sync-service-provider}")
    private String appName;

    // @Bean
    public ApplicationConfig applicationConfig() {
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName(appName);
        return applicationConfig;
    }

}
