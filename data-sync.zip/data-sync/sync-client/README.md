Sync Client - 离港系统数据同步客户端
