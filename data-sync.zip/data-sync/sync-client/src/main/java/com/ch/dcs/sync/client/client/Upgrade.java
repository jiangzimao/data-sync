package com.ch.dcs.sync.client.client;

import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.service.IDataMerge;
import com.ch.dcs.sync.service.IVersionService;
import com.ch.dcs.sync.util.EntityUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Upgrade {

    @Autowired
    private IDataMerge dataMerge;

    @Autowired
    private IVersionService versionService;

    public void persist(List<VersionData> versionDataList) {
        for(VersionData versionData : versionDataList) {
            // 服务端版本信息
            VersionEntity serverVersionEntity = versionData.getVersionEntity();
            // 处理服务端同步到客户端的版本数据
            String bizKey = serverVersionEntity.getBizKey();
            String versionId = serverVersionEntity.getVersionId();
            VersionType versionType = serverVersionEntity.getType();
            String buildId = versionService.getBuildId(versionId, versionType, false);
            if(buildId == null || !buildId.equals(serverVersionEntity.getBuildId())) {
                versionService.createBuildId(serverVersionEntity.getVersionId(), serverVersionEntity.getBuildId(), versionType);
            }
            VersionEntity clientVersionEntity = versionService.getEntity(versionId, versionType, bizKey);
            if (clientVersionEntity == null) {
                clientVersionEntity = serverVersionEntity;
            }
            if ((VersionType.client == versionType && clientVersionEntity.getLocal() < serverVersionEntity.getLocal())
                    || (VersionType.server == versionType && clientVersionEntity.getSubmit() <= serverVersionEntity.getSubmit())) {
                // 保存业务数据
                Object entity = EntityUtil.syncPersist(serverVersionEntity.getBizKey(), versionData.getEntity(), en -> dataMerge.merge(en));
                clientVersionEntity.setCode(EntityUtil.getEntityCode(entity));
                clientVersionEntity.setSubmit(serverVersionEntity.getSubmit());
                if(versionType == VersionType.server && serverVersionEntity.getAppId().equals(clientVersionEntity.getAppId())) {
                    clientVersionEntity.setLocal(serverVersionEntity.getLocal());
                }
                versionService.saveEntity(clientVersionEntity);
            }
        }
    }
}
