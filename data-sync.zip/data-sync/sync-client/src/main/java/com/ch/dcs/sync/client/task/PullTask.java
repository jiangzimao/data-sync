package com.ch.dcs.sync.client.task;

import com.ch.dcs.sync.Sync;
import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.client.client.ClientVersionService;
import com.ch.dcs.sync.client.client.Upgrade;
import com.ch.dcs.sync.core.CustomKeyProvider;
import com.ch.dcs.sync.core.EntityFilter;
import com.ch.dcs.sync.core.VersionCheck;
import com.ch.dcs.sync.model.SyncDemand;
import com.ch.dcs.sync.service.IVersionService;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class PullTask {

    private static final Logger LOG = LoggerFactory.getLogger(PullTask.class);
    private static final PullTask instance = new PullTask();

    private PullTask() {
    }

    public static PullTask getInstance() {
        return instance;
    }

    /**
     * 添加定时任务，根据function提供的versionKey，定时同步数据
     *
     * @param customKeyProvider 提供版本Key的Provider
     * @param versionName       版本名称
     * @param versionType       版本类型
     * @param period            循环周期间隔
     * @param timeout           超时时间
     * @param timeUnit          时间单位
     * @param threadSize        处理同步的线程数
     * @param entityFilter      过滤接口
     */
    public PullTask task(CustomKeyProvider<String[]> customKeyProvider, String versionName, VersionType versionType,
                         Long period, Long timeout, TimeUnit timeUnit, Integer threadSize, Long batchSize, EntityFilter entityFilter) {
        IVersionService versionService = Sync.getContext().getBean(IVersionService.class);
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleWithFixedDelay(() -> {
            ExecutorService fixedExecutor = Executors.newFixedThreadPool(threadSize);
            String[] customKeys;
            try {
                customKeys = customKeyProvider.getCustomKeys();
                if (customKeys == null || customKeys.length == 0) {
                    customKeys = customKeyProvider.getDefaultCustomKeys();
                }
            } catch (Throwable e) {
                LOG.error(String.format("get versionName[%s] custom key error.", versionName), e);
                return;
            }
            List<Future<?>> futureList = new ArrayList<>(customKeys.length);
            for (String customKey : customKeys) {
                Future<?> future = fixedExecutor.submit(() -> {
                    String versionId = String.format("%s:%s", versionName, customKey);
                    Sync.getContext().getBean(VersionCheck.class).addCheckVersionKey(versionId);
                    String buildId = versionService.getBuildId(versionId, versionType, false);
                    Double maxVersion = buildId == null ? 0D : versionService.getMaxVersion(VersionType.server, buildId, versionId);
                    SyncDemand demand = new SyncDemand(buildId, versionName, customKey);
                    demand.setSubmit(maxVersion);
                    demand.setEntityFilter(entityFilter);
                    // IVersionSync versionSync = Sync.getContext().getBean(SyncClient.class).getVersionSync();
                    // List<VersionData> versionDataList = versionSync.pull(Lists.newArrayList(demand), batchSize);
                    ClientVersionService clientVersionService = Sync.getContext().getBean(ClientVersionService.class);
                    List<VersionData> versionDataList = clientVersionService.pull(Lists.newArrayList(demand), batchSize);
                    Upgrade upgrade = Sync.getContext().getBean(Upgrade.class);
                    upgrade.persist(versionDataList);
                });
                futureList.add(future);
            }
            fixedExecutor.shutdown();
            futureList.forEach(future -> {
                try {
                    future.get(timeout, timeUnit);
                } catch (Throwable e) {
                    LOG.error(String.format("pull version[%s] error.", versionName), e);
                }
            });
        }, 1, period, timeUnit);
        return this;
    }

    public void pushStart(Long initialDelay, Long delay, TimeUnit timeUnit) {
        Sync.getContext().getBean(PushTask.class).start(initialDelay, delay, timeUnit);
    }
}