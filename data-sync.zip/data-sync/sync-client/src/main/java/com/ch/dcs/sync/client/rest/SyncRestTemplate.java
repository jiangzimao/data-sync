package com.ch.dcs.sync.client.rest;

import com.ch.dcs.sync.Sync;
import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.client.client.Upgrade;
import com.ch.dcs.sync.model.SyncDemand;
import com.ch.dcs.sync.model.SyncMessage;
import com.ch.dcs.sync.model.PullRequest;
import com.ch.dcs.sync.model.VersionEntities;
import com.ch.dcs.sync.service.IVersionService;
import com.ch.dcs.sync.util.KryoUtil;
import com.google.gson.Gson;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;

import java.util.*;

public class SyncRestTemplate extends RestTemplate {

    private Gson gson = new Gson();

    public <T> T post(String url, Map<String, Object> params, Map<String, String> versionIds,
                      Set<VersionType> versionTypes, Class<T> responseType, Object... uriVariables) {
        HttpHeaders headers = new HttpHeaders();
        if(versionIds != null) {
            IVersionService versionService = Sync.getContext().getBean(IVersionService.class);
            List<SyncDemand> syncDemands = new ArrayList<>();
            for (Map.Entry<String, String> entry : versionIds.entrySet()) {
                if(versionTypes == null) {
                    versionTypes = new HashSet<>();
                }
                if(versionTypes.size() == 0) {
                    versionTypes.add(VersionType.server);
                }
                for(VersionType versionType : versionTypes) {
                    String versionId = String.format("%s:%s", entry.getKey(), entry.getValue());
                    String buildId = versionService.getBuildId(versionId, versionType, false);
                    Double version = versionService.getMaxVersion(versionType, buildId, versionId);
                    SyncDemand syncDemand = new SyncDemand(buildId, entry.getKey(), entry.getValue());
                    if(versionType == VersionType.server) {
                        syncDemand.setSubmit(version);
                    } else {
                        syncDemand.setLocal(version);
                    }
                    syncDemands.add(syncDemand);
                }
            }
            headers.add("Check-Version", KryoUtil.writeObjectToString(new PullRequest(syncDemands)));
        }
        return execute(url, HttpMethod.POST, params, responseType, headers, uriVariables);
    }

    public <T> T get(String url, Map<String, Object> params, Class<T> responseType, Object... uriVariables) {
        HttpHeaders headers = new HttpHeaders();
        return execute(url, HttpMethod.GET, params, responseType, headers, uriVariables);
    }

    private <T> T execute(String url, HttpMethod method, Map<String, Object> params, Class<T> responseType,
                          HttpHeaders headers, Object... ruiVariables) {
        long startTime = System.currentTimeMillis();
        MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
        for(Map.Entry<String, List<String>> entry : headers.entrySet()) {
            StringBuilder values = new StringBuilder();
            for(String value : entry.getValue()){
                values.append(";").append(value);
            }
            multiValueMap.add(entry.getKey(), values.substring(1));
        }
        ResponseEntity<T> responseEntity;
        ///*
        if(method.equals(HttpMethod.POST) && headers.containsKey("Check-Version")) {
            HttpEntity<String> request = new HttpEntity<>(serializeMap(params), multiValueMap);
            RequestCallback requestCallback = httpEntityCallback(request, responseType);
            ResponseExtractor<ResponseEntity<String>> responseExtractor = responseEntityExtractor(responseType);
            long postTime = System.currentTimeMillis();
            ResponseEntity<String> syncResponseEntity = execute(url, method, requestCallback, responseExtractor, ruiVariables);
            postTime = System.currentTimeMillis() - postTime;
            String body = syncResponseEntity.getBody();
            if(body != null) {
                SyncMessage message = gson.fromJson(body, SyncMessage.class);
                String versionData = message.getVersionData();
                long persistTime = 0;
                if(!StringUtils.isEmpty(versionData)) {
                    // 清空 checkData
                    message.setVersionData(null);
                    VersionEntities versionResponse = KryoUtil.readObjectFromString(versionData, VersionEntities.class);
                    List<VersionData> versionDataList = versionResponse.getVersionDataList();
                    if(versionDataList.size() > 0) {
                        persistTime = System.currentTimeMillis();
                        Sync.getContext().getBean(Upgrade.class).persist(versionDataList);
                        persistTime = System.currentTimeMillis() - persistTime;
                    }
                    System.out.println(String.format("request finish time %s ms. post time %s ms, persist time %s ms", System.currentTimeMillis() - startTime, postTime, persistTime));
                }
                return (T) gson.toJson(message);
            }
            return null;
        }
        //*/
        HttpEntity<String> request = new HttpEntity<>(serializeMap(params), multiValueMap);
        RequestCallback requestCallback = httpEntityCallback(request, responseType);
        ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
        responseEntity = execute(url, method, requestCallback, responseExtractor, ruiVariables);
        return responseEntity.getBody();
    }

    private String serializeMap(Map<String, Object> map) {
        if(map == null || map.size() == 0) {
            return null;
        }
        StringBuilder path = new StringBuilder();
        for(Map.Entry<String, Object> entry : map.entrySet()) {
            path.append("&").append(entry.getKey()).append("=").append(entry.getValue());
        }
        return path.substring(1);
    }

}
