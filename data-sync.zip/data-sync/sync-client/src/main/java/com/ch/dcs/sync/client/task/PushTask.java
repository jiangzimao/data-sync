package com.ch.dcs.sync.client.task;

import com.ch.dcs.sync.Sync;
import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.client.SyncClient;
import com.ch.dcs.sync.client.client.ClientVersionService;
import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.service.IDataProvision;
import com.ch.dcs.sync.service.IVersionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

@Component
public class PushTask {

    private static final Logger LOG = LoggerFactory.getLogger(PushTask.class);

    @Autowired
    private IVersionService versionService;
    @Autowired
    private IDataProvision dataProvision;

    private AtomicBoolean start = new AtomicBoolean(Boolean.FALSE);

    public void start(Long initialDelay, Long delay, TimeUnit timeUnit) {
        if(start.compareAndSet(Boolean.FALSE, Boolean.TRUE)) {
            ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
            executor.scheduleWithFixedDelay(this::push, initialDelay, delay, timeUnit);
            LOG.info("push task successful start.");
        } else {
            LOG.warn("push task already started.");
        }
    }

    private void push() {
        List<VersionData> pushDataList = new ArrayList<>();
        // 先查出哪些未提交的版本信息
        List<VersionEntity> clientVersionList = versionService.findAllByType(VersionType.client);
        // 获取对应的业务数据
        clientVersionList.forEach(versionEntity -> {
            String[] vis = versionEntity.getVersionId().split(":");
            Set<Class<?>> classSet = SyncContext.getClassByName(vis[0]);
            Object entity = dataProvision.getBizEntityByKey(versionEntity.getBizKey(), classSet);
            pushDataList.add(new VersionData(versionEntity, entity));
        });
        if(pushDataList.size() > 0) {
            try {
                // 提交
                // Map<String, Boolean> result = Sync.getContext().getBean(SyncClient.class).getVersionSync().push(pushDataList);
                ClientVersionService clientVersionService = Sync.getContext().getBean(ClientVersionService.class);
                Map<String, Boolean> result = clientVersionService.push(pushDataList);
                if(result != null) {
                    result.forEach((entityKey, success) -> {
                        if(success) {
                            versionService.updateTypeByBizKey(VersionType.server, entityKey);
                        }
                    });
                }
            } catch (Exception e) {
                LOG.error("sync client push error.", e);
            }
        }
    }

}
