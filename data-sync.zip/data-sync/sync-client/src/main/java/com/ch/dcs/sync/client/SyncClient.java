package com.ch.dcs.sync.client;

import com.alibaba.dubbo.config.annotation.Reference;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.api.service.IVersionSync;
import com.ch.dcs.sync.client.util.RestTemplateUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Map;
import java.util.Set;

@Component
public class SyncClient {

    @Reference(timeout = 10000)
    private IVersionSync versionSync;

    public IVersionSync getVersionSync() {
        return versionSync;
    }

    public static String request(String url, Map<String, Object> params, RequestMethod method,
                                 Map<String, String> versionIds, Set<VersionType> versionTypes) {
        String responseBody;
        if(RequestMethod.POST.equals(method)) {
            responseBody = RestTemplateUtils.post(url, params, versionIds, versionTypes, String.class);
        } else {
            responseBody = RestTemplateUtils.get(url, params, String.class);
        }
        return responseBody;
    }

}
