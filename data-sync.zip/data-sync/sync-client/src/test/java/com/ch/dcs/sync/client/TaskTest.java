package com.ch.dcs.sync.client;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class TaskTest {

    private static final AtomicLong l = new AtomicLong(0) ;

    private static final ScheduledExecutorService scheduler =
            Executors.newScheduledThreadPool(10);

    @Test
    public void scheduleAtFixedRateTest() throws InterruptedException {
        AtomicInteger number = new AtomicInteger(0);
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(5, new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                return new Thread("thread_" + number.incrementAndGet());
            }
        });
        executor.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                System.out.println("scheduleAtFixedRate:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                try {
                    TimeUnit.SECONDS.sleep(7);
                } catch (InterruptedException e) {
                }
            }
        }, 0, 5, TimeUnit.SECONDS);
        TimeUnit.DAYS.sleep(1);
    }

    @Test
    public void scheduleWithFixedDelayTest() throws InterruptedException {
        AtomicInteger number = new AtomicInteger(0);
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(5, new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                return new Thread("thread_" + number.incrementAndGet());
            }
        });
        executor.scheduleWithFixedDelay(new Runnable() {
            @Override
            public void run() {
                System.out.println("scheduleWithFixedDelay:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                try {
                    TimeUnit.SECONDS.sleep(7);
                } catch (InterruptedException e) {
                }
            }
        }, 0, 5, TimeUnit.SECONDS);
        executor.shutdown();
        TimeUnit.DAYS.sleep(1);
    }

    public static void main(String[] args) {

        /*
         * 使用scheduleAtFixedRate ， 该方法第三个参数表示在上一个个任务开始执行之后延迟
         * 多少秒之后再执行， 是从上一个任务开始时开始计算
         * 但是还是会等上一个任务执行完之后，下一个任务才开始执行，最后的结果，就是感觉延迟失去
         * 了作用
         *  */
        ScheduledFuture<?> sf1 = scheduler.scheduleAtFixedRate(new Runnable() {
            public void run() {
                long i =  l.getAndAdd(1) ;
                System.out.println("start " + i);
                try {
                    TimeUnit.SECONDS.sleep(5) ;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("end " + i);
            }
        }, 0, 2 , TimeUnit.SECONDS) ;

        /*
         * 使用<span style="color: rgb(54, 46, 43); line-height: 20px;">scheduleWithFixedDelay</span>， 该方法第三个参数表示在上一个个任务结束执行之后延迟
         * 多少秒之后再执行， 是从上一个任务结束时开始计算
         *  */
        ScheduledFuture<?> sf2 = scheduler.scheduleWithFixedDelay(new Runnable() {
            public void run() {
                long i =  l.getAndAdd(1) ;
                System.out.println("start " + i);
                try {
                    TimeUnit.SECONDS.sleep(3) ;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("end " + i);
            }
        }, 0, 2, TimeUnit.SECONDS) ;
    }

}
