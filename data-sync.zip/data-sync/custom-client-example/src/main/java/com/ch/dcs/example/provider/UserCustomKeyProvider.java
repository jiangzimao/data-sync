package com.ch.dcs.example.provider;

import com.ch.dcs.sync.core.CustomKeyProvider;

public class UserCustomKeyProvider extends CustomKeyProvider<String[]> {

    public UserCustomKeyProvider(String... defaultCustomKeys) {
        super(defaultCustomKeys);
    }

    @Override
    public String[] getCustomKeys() {
        // TODO 获取要同步的版本主键
        return null;
    }
}
