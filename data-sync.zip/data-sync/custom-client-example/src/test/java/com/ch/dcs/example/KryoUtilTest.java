package com.ch.dcs.example;

import com.ch.dcs.example.entity.UserEntity;
import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.model.VersionEntities;
import com.ch.dcs.sync.util.KryoUtil;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class KryoUtilTest {

    @Test
    public void decode() {
        VersionEntities response = new VersionEntities();
        List<VersionData> versionDataList = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            VersionData versionData = new VersionData();
            versionData.setEntity(new UserEntity("air"+i, i, new Date()));
            versionData.setVersionEntity(new VersionEntity("a"+i, "b" + i, VersionType.server));
            versionDataList.add(versionData);
        }
        response.setVersionDataList(versionDataList);
        String src = KryoUtil.writeObjectToString(response);
        System.out.println(src.length());
        System.out.println(src);
        VersionEntities after = KryoUtil.readObjectFromString(src, VersionEntities.class);
        System.out.println(after);
    }

}
