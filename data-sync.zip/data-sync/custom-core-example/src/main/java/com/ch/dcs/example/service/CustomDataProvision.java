package com.ch.dcs.example.service;

import com.ch.dcs.example.repository.UserRepository;
import com.ch.dcs.sync.service.IDataProvision;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class CustomDataProvision implements IDataProvision {

    @Autowired
    private UserRepository userRepository;

    @Override
    public <T> T getBizEntityByKey(String bizKey, Set<Class<?>> classSet) {
        return (T) userRepository.findByUui(bizKey);
    }

    @Override
    public <T> List<T> findEntities(String typeVersionValue, String fieldVersionValue) {
        // dcs_user:sha
        List entities = userRepository.findAllByAir(fieldVersionValue);
        // TODO
        return entities;
    }
}
