package com.ch.dcs.example.filter;

import com.ch.dcs.example.entity.UserEntity;
import com.ch.dcs.sync.core.EntityFilter;

import java.io.Serializable;

public class UserEntityFilter extends EntityFilter<UserEntity> implements Serializable {

    private Integer age;

    public UserEntityFilter() {
    }

    public UserEntityFilter(Integer age) {
        this.age = age;
    }

    @Override
    public Boolean filter(UserEntity entity) {
        if(entity.getAge() > age) {
            return true;
        }
        return false;
    }
}
