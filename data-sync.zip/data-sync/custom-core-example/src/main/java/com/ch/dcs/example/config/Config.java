package com.ch.dcs.example.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.ch.dcs.example.entity.PaxEntity;
import com.ch.dcs.example.entity.SeatEntity;
import com.ch.dcs.example.entity.UserEntity;
import com.ch.dcs.sync.Sync;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
public class Config extends PropertiesConfig {

    @PostConstruct
    public void init(){
        Sync.versionConfig("dcs_user", "air", "uui", UserEntity.class, "createDate", "inDate");
        Sync.versionConfig("dcs_leg", "lu", "uui", PaxEntity.class);
        Sync.versionConfig("dcs_leg", "lu", "uui", SeatEntity.class);
    }

    @Bean("dataSource")
    @Qualifier("dataSource")
    @Primary
    public DataSource dataSource(){
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }

}
