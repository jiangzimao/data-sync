package com.ch.dcs.example.controller;

import com.ch.dcs.example.entity.UserEntity;
import com.ch.dcs.example.repository.UserRepository;
import com.ch.dcs.sync.Sync;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.model.SyncMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.UUID;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @RequestMapping(value = "test", method = RequestMethod.POST)
    public SyncMessage<VersionEntity> addTest(){
        UserEntity userEntity = new UserEntity("sha", 88, new Date());
        userEntity.setUui(UUID.randomUUID().toString().replace("-", ""));
        userRepository.save(userEntity);
        return SyncMessage.result(Sync.submit(userEntity));
    }

}
