package com.ch.dcs.example.entity;

import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;

@MappedSuperclass
public abstract class UuiEntity implements Serializable {

    @Id
    private String uui;

    public String getUui() {
        return uui;
    }

    public void setUui(String uui) {
        this.uui = uui;
    }
}
