package com.ch.dcs.example.repository;

import com.ch.dcs.example.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, String> {

    UserEntity findByUui(String bizKey);

    List<UserEntity> findAllByAir(String fieldVersionValue);
}
