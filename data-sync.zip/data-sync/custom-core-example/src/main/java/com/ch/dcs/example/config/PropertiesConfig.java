package com.ch.dcs.example.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertiesConfig {

    @Value("${spring.datasource.driver-class-name:org.h2.Driver}")
    protected String driverClassName;
    @Value("${spring.datasource.url:jdbc:h2:file:.\\data\\server;MODE=MySQL;AUTO_SERVER=TRUE}")
    protected String url;
    @Value("${spring.datasource.username:sa}")
    protected String username;
    @Value("${spring.datasource.password:sa}")
    protected String password;


}
