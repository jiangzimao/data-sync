package com.ch.dcs.example.service;

import com.ch.dcs.example.entity.UserEntity;
import com.ch.dcs.example.entity.UuiEntity;
import com.ch.dcs.example.repository.UserRepository;
import com.ch.dcs.sync.service.IDataMerge;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomDataMerger implements IDataMerge<UuiEntity> {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UuiEntity merge(UuiEntity entity) {
        // TODO 实现数据合并功能
        UuiEntity uuiEntity = userRepository.findByUui(entity.getUui());
        if(uuiEntity != null) {
            entity.setUui(uuiEntity.getUui());
        }
        userRepository.save((UserEntity) entity);
        return entity;
    }

    @Override
    public UuiEntity upgrade(UuiEntity entity) {
        UuiEntity uuiEntity = userRepository.findByUui(entity.getUui());
        if(uuiEntity != null) {
            entity.setUui(uuiEntity.getUui());
        }
        userRepository.save((UserEntity) entity);
        return entity;
    }
}
