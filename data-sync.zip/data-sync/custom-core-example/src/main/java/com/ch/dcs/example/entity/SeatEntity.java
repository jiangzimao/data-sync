package com.ch.dcs.example.entity;

public class SeatEntity extends UuiEntity {
    private Long lu;
    private Integer rn;
    private String cn;

    public SeatEntity(Long lu, Integer rn, String cn) {
        this.lu = lu;
        this.rn = rn;
        this.cn = cn;
    }

    public Long getLu() {
        return lu;
    }

    public void setLu(Long lu) {
        this.lu = lu;
    }

    public Integer getRn() {
        return rn;
    }

    public void setRn(Integer rn) {
        this.rn = rn;
    }

    public String getCn() {
        return cn;
    }

    public void setCn(String cn) {
        this.cn = cn;
    }

    @Override
    public String toString() {
        return "SeatEntity{" +
                "lu=" + lu +
                ", rn=" + rn +
                ", cn='" + cn + '\'' +
                '}';
    }
}
