package com.ch.dcs.example.entity;

import javax.persistence.Entity;
import java.util.Date;

@Entity(name = "dcs_user")
public class UserEntity extends UuiEntity {

    private String air;
    private Integer age;
    private Date inDate;
    private Date createDate = new Date();

    public UserEntity() {
    }

    public UserEntity(String air, Integer age, Date inDate) {
        this.age = age;
        this.air = air;
        this.inDate = inDate;
    }


    public String getAir() {
        return air;
    }

    public void setAir(String air) {
        this.air = air;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Date getInDate() {
        return inDate;
    }

    public void setInDate(Date inDate) {
        this.inDate = inDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    @Override
    public String toString() {
        return "UserEntity{" +
                "air='" + air + '\'' +
                ", age=" + age +
                ", inDate=" + inDate +
                ", createDate=" + createDate +
                '}';
    }
}
