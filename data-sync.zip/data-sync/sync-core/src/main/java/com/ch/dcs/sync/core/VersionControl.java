package com.ch.dcs.sync.core;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.ex.SyncException;
import com.ch.dcs.sync.service.impl.VersionService;
import com.ch.dcs.sync.util.EntityUtil;
import com.ch.dcs.sync.util.KeyUtil;
import com.ch.dcs.sync.util.RedisLock;

import java.util.concurrent.TimeUnit;

public class VersionControl {

    public static <T> VersionEntity submit(T entity, Object... other){
        return upgrade(entity, true, other);
    }

    public static <T> VersionEntity sync(T entity){
        return upgrade(entity, false);
    }

    private static <T> VersionEntity upgrade(T entity, boolean upgrade, Object... other) {

        if (entity == null) {
            throw new SyncException("submit version failed. entity can not be null.");
        }
        // get version id
        String versionId = KeyUtil.getVersionId(entity);
        // get entity code
        String entityCode = EntityUtil.getEntityCode(entity);
        // get bizKey
        String bizKey = EntityUtil.getBizKey(entity);
        VersionService versionService = SyncContext.getBean(VersionService.class);
        // long s = System.currentTimeMillis();
        // get build id
        String buildId = other != null && other.length > 0 ? other[0].toString():
                versionService.getBuildId(versionId, SyncContext.getVersionType(), upgrade);
        String versionKey = KeyUtil.getVersionKey(SyncContext.getVersionType(), buildId, versionId);
        if (RedisLock.tryLock(versionKey, 45, 60, TimeUnit.SECONDS)) {
            try {
                // long start = System.currentTimeMillis();
                // init version entity
                VersionEntity versionEntity = versionService.getEntity(versionId, SyncContext.getVersionType(), bizKey);
                if(versionEntity == null) {
                    versionEntity = new VersionEntity();
                }
                versionEntity.setVersionId(versionId);
                versionEntity.setBizKey(bizKey);
                versionEntity.setBuildId(buildId);
                versionEntity.setCode(entityCode);

                if(upgrade){
                    versionEntity.setAppId(SyncContext.getAppId());
                    versionEntity.setType(SyncContext.getVersionType());
                    // get version number
                    Double nextVersion = versionService.getNextVersion(versionKey);
                    if(SyncContext.getVersionType() == VersionType.server) {
                        versionEntity.setSubmit(nextVersion);
                        if(other != null && other.length > 2) {
                            versionEntity.setLocal(Double.parseDouble(other[1].toString()));
                            versionEntity.setAppId(other[2].toString());
                        }
                    } else {
                        versionEntity.setLocal(nextVersion);
                    }
                }

                // update version entity
                versionService.saveEntity(versionEntity);
                return versionEntity;
            } finally {
                RedisLock.unLock(versionKey);
            }
        } else {
            throw new SyncException(String.format("get lock[%s] result is false.", versionId));
        }
    }

}
