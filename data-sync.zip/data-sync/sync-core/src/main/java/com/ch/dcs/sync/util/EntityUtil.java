package com.ch.dcs.sync.util;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.core.ISyncPersist;
import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.ex.SyncException;
import sun.misc.BASE64Encoder;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.security.MessageDigest;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

public abstract class EntityUtil {

    @Deprecated
    public static <T> String getFieldValue(T entity, Class<? extends Annotation> annotation, boolean allowNull) {
        List<Field> versionIdFields = ClassUtil.getFieldsByAnnotation(entity.getClass(), annotation);
        if (versionIdFields.size() > 0) {
            Field field = versionIdFields.get(0);
            try {
                return field.get(entity).toString();
            } catch (Exception e) {
                throw new SyncException(String.format("get value of %s error. %s", field.getName(), e.getMessage()), e);
            }
        } else if(!allowNull){
            throw new SyncException(String.format("the entity must have a field with %s annotations",
                    annotation.getSimpleName()));
        }
        return null;
    }

    public static <T> String getEntityCode(T entity) {
        try {
            // get fields
            Field[] fields = ClassUtil.getFields(entity.getClass());
            TreeMap<String, Field> fieldTreeMap = new TreeMap<>();
            for (Field field : fields) {
                if(!SyncContext.getExclusionFields(entity.getClass()).contains(field.getName())) {
                    field.setAccessible(Boolean.TRUE);
                    fieldTreeMap.put(field.getName(), field);
                }
            }

            // get field value
            StringBuilder info = new StringBuilder();
            do {
                Map.Entry<String, Field> entry = fieldTreeMap.pollFirstEntry();
                Object value = entry.getValue().get(entity);
                if (value != null) {
                    info.append(value.toString());
                }
            } while (fieldTreeMap.size() > 0);

            // md5 code
            return new BASE64Encoder().encode(MessageDigest.getInstance("MD5").digest(info.toString().getBytes("UTF-8")));
        } catch (Throwable e) {
            throw new SyncException(String.format("get %s entity code error.", entity), e);
        }
    }

    public static String getBizKey(Object entity) {
        Field bizKeyFiled = SyncContext.getBizKeyFiled(entity.getClass());
        return getFiledValue(entity, bizKeyFiled).toString();
    }

    public static String getCustomKey(Object entity) {
        Field customKeyField = SyncContext.getCustomKeyField(entity.getClass());
        return getFiledValue(entity, customKeyField).toString();
    }

    public static <T> T syncPersist(String bizKey, T entity, ISyncPersist<T> syncPersist) {
        String lockKey = String.format("persist_entity_sync_%s", bizKey);
        if(JvmLock.tryLock(lockKey, 60, TimeUnit.SECONDS)) {
            try {
                return syncPersist.doSyncPersist(entity);
            } finally {
                JvmLock.unLock(lockKey);
            }
        } else {
            throw new SyncException(String.format("persist entity error. try lock %s result is false.", lockKey));
        }
    }

    public static double getEntityScore(VersionEntity entity) {
        return entity.getType() == VersionType.server ? entity.getSubmit() : entity.getLocal();
    }

    private static Object getFiledValue(Object entity, Field filed) {
        try {
            Object fieldValue = filed.get(entity);
            if(fieldValue == null) {
                throw new SyncException(String.format("the filed %s value of %s is null",
                        filed.getName(), entity.getClass().getSimpleName()));
            }
            return fieldValue;
        } catch (Throwable e) {
            if(e instanceof SyncException) {
                throw (SyncException) e;
            }
            throw new SyncException("get filed value error.", e);
        }
    }
}
