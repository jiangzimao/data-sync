package com.ch.dcs.sync.core;

import com.ch.dcs.sync.Sync;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.entity.VersionEntity;
import com.ch.dcs.sync.repository.VersionRepository;
import com.ch.dcs.sync.service.IDataProvision;
import com.ch.dcs.sync.service.IVersionService;
import com.ch.dcs.sync.util.EntityUtil;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Component
public class VersionCheck {

    private static final Logger LOG = LoggerFactory.getLogger(VersionCheck.class);

    private Cache<String, Long> checkCache = CacheBuilder.newBuilder().expireAfterAccess(10, TimeUnit.MINUTES).build();

    @Autowired
    private IDataProvision dataProvision;

    @Autowired
    private IVersionService versionService;

    @PostConstruct
    private void check() {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleWithFixedDelay(this::checkEntityCode, 1, 5, TimeUnit.SECONDS);
    }

    public void addCheckVersionKey(String versionId) {
        if(checkCache.getIfPresent(versionId) == null) {
            checkCache.put(versionId, System.currentTimeMillis());
        }
    }

    private void checkEntityCode() {
        ConcurrentMap<String, Long> checkMap = checkCache.asMap();
        if(!checkMap.isEmpty()) {
            checkMap.forEach((versionId, lastCheckTime) -> {
                if(System.currentTimeMillis() - lastCheckTime > 1000 * 1) {
                    checkCache.put(versionId, System.currentTimeMillis());
                    String[] versions = versionId.split(":");
                    List<Object> entities = dataProvision.findEntities(versions[0], versions[1]);
                    if(entities != null && entities.size() > 0) {
                        entities.forEach(entity -> {
                            String code = EntityUtil.getEntityCode(entity);
                            String bizKey = EntityUtil.getBizKey(entity);
                            VersionEntity versionEntity = versionService.getEntity(versionId, SyncContext.getVersionType(), bizKey);
                            if(versionEntity == null || !code.equals(versionEntity.getCode())) {
                                if(versionEntity == null && VersionType.client == SyncContext.getVersionType()) {
                                    // 有可能存在于服务端版本
                                    versionEntity = versionService.getEntity(versionId, VersionType.server, bizKey);
                                    if(versionEntity != null && code.equals(versionEntity.getCode())) {
                                        return;
                                    }
                                }
                                versionEntity = Sync.submit(entity);
                                versionService.saveEntity(versionEntity);
                            }
                        });
                    }
                }
            });
        }
    }

}
