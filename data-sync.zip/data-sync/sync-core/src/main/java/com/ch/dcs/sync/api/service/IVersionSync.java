package com.ch.dcs.sync.api.service;

import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.model.SyncDemand;

import java.util.List;
import java.util.Map;

public interface IVersionSync {

    List<VersionData> pull(List<SyncDemand> requestList, Long batchSize);

    Map<String, Boolean> push(List<VersionData> versionDataList);
}
