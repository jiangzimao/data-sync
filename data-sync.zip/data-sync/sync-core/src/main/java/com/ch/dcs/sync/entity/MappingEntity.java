package com.ch.dcs.sync.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "sync_mapping")
public class MappingEntity implements Serializable {

    @Id
    private String mappingKey;
    private String buildId;

    public MappingEntity() {
    }

    public MappingEntity(String mappingKey) {
        this();
        this.mappingKey = mappingKey;
    }

    public String getMappingKey() {
        return mappingKey;
    }

    public void setMappingKey(String mappingKey) {
        this.mappingKey = mappingKey;
    }

    public String getBuildId() {
        return buildId;
    }

    public void setBuildId(String buildId) {
        this.buildId = buildId;
    }
}
