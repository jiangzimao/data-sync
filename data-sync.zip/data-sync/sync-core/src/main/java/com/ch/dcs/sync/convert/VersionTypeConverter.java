package com.ch.dcs.sync.convert;

import com.ch.dcs.sync.api.mode.VersionType;
import org.apache.commons.beanutils.Converter;
import org.springframework.util.StringUtils;

public class VersionTypeConverter implements Converter {
    @Override
    public <T> T convert(Class<T> type, Object value) {
        if(StringUtils.isEmpty(value.toString())) {
            return null;
        }
        return (T) VersionType.valueOf(value.toString());
    }
}
