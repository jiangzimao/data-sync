package com.ch.dcs.sync.model;

import java.io.Serializable;

public class SyncMessage<T> implements Serializable {

    private T result;
    private Boolean success = true;
    private String message;
    private String versionData;

    public SyncMessage() {
    }

    public SyncMessage(Boolean success) {
        this();
        this.success = success;
    }

    public SyncMessage(T result) {
        this(true);
        this.result = result;
    }

    public SyncMessage(T result, String message) {
        this(result);
        this.message = message;
    }

    public T getResult() {
        return result;
    }

    public void setResult(T result) {
        this.result = result;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getVersionData() {
        return versionData;
    }

    public void setVersionData(String versionData) {
        this.versionData = versionData;
    }

    public static <T> SyncMessage<T> result(T result) {
        return new SyncMessage<>(result);
    }

    public static <T> SyncMessage<T> success() {
        return new SyncMessage<>(true);
    }

    public static <T> SyncMessage<T> error() {
        return new SyncMessage<>(false);
    }

    public static <T> SyncMessage<T> error(String message) {
        SyncMessage<T> syncMessage = new SyncMessage<>(false);
        syncMessage.setMessage(message);
        return syncMessage;
    }

    @Override
    public String toString() {
        return "SyncMessage{" +
                "result=" + result +
                ", success=" + success +
                ", message='" + message + '\'' +
                ", versionData='" + versionData + '\'' +
                '}';
    }
}
