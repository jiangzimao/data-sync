package com.ch.dcs.sync.repository;

import com.ch.dcs.sync.entity.MappingEntity;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface MappingRepository extends CrudRepository<MappingEntity, String> {

    @Query("select buildId from MappingEntity where mappingKey = ?1")
    String getBuildIdByMappingKey(String mappingKey);

    MappingEntity findByMappingKey(String mappingKey);

    @Transactional
    @Modifying
    @Query("delete from MappingEntity where mappingKey = ?1")
    Integer deleteByMappingKey(String mappingKey);
}
