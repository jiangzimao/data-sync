package com.ch.dcs.sync.config;

import com.alibaba.druid.pool.DruidDataSource;

public class SyncDataSource extends DruidDataSource {

    public String getDriverClassName() {
        return driverClass;
    }

    public void setDriverClassName(String driverClassName) {
        this.driverClass = driverClassName;
    }

    public String getUrl() {
        return jdbcUrl;
    }

    public void setUrl(String url) {
        this.jdbcUrl = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
