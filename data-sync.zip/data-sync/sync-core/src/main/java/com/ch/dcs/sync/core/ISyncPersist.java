package com.ch.dcs.sync.core;

public interface ISyncPersist<T> {

    T doSyncPersist(T entity);

}
