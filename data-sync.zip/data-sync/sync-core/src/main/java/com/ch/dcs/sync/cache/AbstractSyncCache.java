package com.ch.dcs.sync.cache;

import com.ch.dcs.sync.core.VersionControl;
import com.ch.dcs.sync.service.IDataProvision;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.UUID;

public abstract class AbstractSyncCache implements ISyncCache{

    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    private IDataProvision dataProvision;

    public AbstractSyncCache(IDataProvision dataProvision) {
        this.dataProvision = dataProvision;
    }

    protected String initBuildVersion(String versionId, String buildId) {
        if(StringUtils.isEmpty(buildId)){
            buildId = UUID.randomUUID().toString();
            // init version entities
            String[] versionInfo = versionId.split(":");
            List<Object> bizEntities = dataProvision.findEntities(versionInfo[0], versionInfo[1]);
            String finalBuildId = buildId;
            bizEntities.forEach(entity -> {
                VersionControl.submit(entity, finalBuildId);
            });
        }
        return buildId;
    }
}
