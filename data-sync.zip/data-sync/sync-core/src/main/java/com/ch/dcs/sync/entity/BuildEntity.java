package com.ch.dcs.sync.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "sync_build")
public class BuildEntity implements Serializable {

    @Id
    private String buildKey;
    private String buildId;

    public BuildEntity() {
    }

    public BuildEntity(String buildKey) {
        this();
        this.buildKey = buildKey;
    }

    public String getBuildKey() {
        return buildKey;
    }

    public void setBuildKey(String buildKey) {
        this.buildKey = buildKey;
    }

    public String getBuildId() {
        return buildId;
    }

    public void setBuildId(String buildId) {
        this.buildId = buildId;
    }
}
