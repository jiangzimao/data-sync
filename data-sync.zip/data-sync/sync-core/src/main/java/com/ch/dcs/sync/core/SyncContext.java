package com.ch.dcs.sync.core;

import com.ch.dcs.sync.config.SyncConfig;
import com.ch.dcs.sync.config.SyncDataSource;
import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.ex.SyncException;
import com.ch.dcs.sync.model.VersionMapping;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Order(0)
@Component("syncContext")
public class SyncContext implements ApplicationContextAware {

    private static ApplicationContext context;

    private static final Map<String, VersionMapping> versionMappingMap = new ConcurrentHashMap<>();
    private static final Map<Class<?>, String> entityVersionNameMap = new ConcurrentHashMap<>();
    private static final Map<String, Set<Class<?>>> versionNameClassMap = new ConcurrentHashMap<>();

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        SyncContext.context = applicationContext;
    }

    public static ApplicationContext getContext() {
        return context;
    }

    public static <T> T getBean(Class<T> cls) {
        return context.getBean(cls);
    }

    public static <T> T getBean(String name, Class<T> cls) {
        return context.getBean(name, cls);
    }

    public static VersionType getVersionType() {
        return context.getBean(SyncConfig.class).getVersionType();
    }

    public static String getRedisPrefix() {
        return context.getBean(SyncConfig.class).getRedisPrefix();
    }

    public static String getAppId() {
        return context.getBean(SyncConfig.class).getAppId();
    }

    public static void registerVersion(String name, String customKey, String bizKey, Class<?> cla, String... exclusionFields) {
        VersionMapping mapping = versionMappingMap.computeIfAbsent(name, VersionMapping::new);
        if(customKey != null && !"".equals(customKey.trim())){
            mapping.addField(cla, customKey, bizKey, exclusionFields);
        } else {
            mapping.addClass(cla, bizKey, exclusionFields);
        }
        versionNameClassMap.computeIfAbsent(name, key -> new HashSet<>()).add(cla);
        entityVersionNameMap.put(cla, name);
    }

    public static Set<String> getExclusionFields(Class<?> cla) {
        String key = entityVersionNameMap.get(cla);
        return versionMappingMap.get(key).getExclusionFields(cla);
    }

    public static Field getBizKeyFiled(Class<?> cla) {
        String key = entityVersionNameMap.get(cla);
        return versionMappingMap.get(key).getBizKeyMapping().get(cla);
    }

    public static String getVersionName(Class<?> cla) {
        return entityVersionNameMap.get(cla);
    }

    public static Field getCustomKeyField(Class<?> cla) {
        String key = entityVersionNameMap.get(cla);
        try {
            return versionMappingMap.get(key).getCustomKeyField(cla);
        } catch (Exception e) {
            e.printStackTrace();
            throw new SyncException(e);
        }
    }

    public static Set<Class<?>> getClassByName(String name) {
        return versionNameClassMap.computeIfAbsent(name, (key) -> {
            Set<Class<?>> temp = new HashSet<>();
            for(Map.Entry<Class<?>, String> entry : entityVersionNameMap.entrySet()) {
                if(name.equals(entry.getValue())) {
                    temp.add(entry.getKey());
                }
            }
            return temp;
        });
    }
}
