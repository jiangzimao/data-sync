package com.ch.dcs.sync.model;

import com.ch.dcs.sync.api.mode.VersionData;

import java.io.Serializable;
import java.util.List;

public class VersionEntities implements Serializable {

    private List<VersionData> versionDataList;

    public VersionEntities() {
    }

    public VersionEntities(List<VersionData> versionDataList) {
        this.versionDataList = versionDataList;
    }

    public List<VersionData> getVersionDataList() {
        return versionDataList;
    }

    public void setVersionDataList(List<VersionData> versionDataList) {
        this.versionDataList = versionDataList;
    }
}
