package com.ch.dcs.sync.model;

public enum SyncDbType {

    redis, h2, mysql, oracle

}
