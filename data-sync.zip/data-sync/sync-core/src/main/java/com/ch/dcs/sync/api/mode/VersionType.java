package com.ch.dcs.sync.api.mode;

public enum VersionType {
    client, server
}
