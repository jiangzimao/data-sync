package com.ch.dcs.sync.config;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.cache.DefaultSyncCache;
import com.ch.dcs.sync.cache.ISyncCache;
import com.ch.dcs.sync.cache.RedisSyncCache;
import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.model.SyncDbType;
import com.ch.dcs.sync.repository.BuildRepository;
import com.ch.dcs.sync.repository.MappingRepository;
import com.ch.dcs.sync.repository.SerialRepository;
import com.ch.dcs.sync.repository.VersionRepository;
import com.ch.dcs.sync.service.IDataProvision;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.redis.core.RedisTemplate;

@Configuration
public class SyncConfig extends SyncPropertiesConfig {

    public String getRedisPrefix() {
        return redisPrefix;
    }

    public String getAppId() {
        return appId;
    }

    public VersionType getVersionType() {
        if(versionType != null && !"".equals(versionType.trim())) {
            return VersionType.valueOf(versionType.toLowerCase());
        }
        return null;
    }

    public String getH2Path() {
        return h2Path;
    }

    public SyncDbType getDbType() {
        if(dbType != null && !"".equals(dbType.trim())) {
            return SyncDbType.valueOf(dbType.toLowerCase());
        }
        return null;
    }

    @DependsOn("syncContext")
    @Bean("syncCache")
    public ISyncCache syncCache(){
        IDataProvision dataProvision = SyncContext.getBean(IDataProvision.class);
        if(getDbType() == SyncDbType.redis){
            // return redis cache
            RedisTemplate redisTemplate = SyncContext.getBean("syncRedisTemplate", RedisTemplate.class);
            return new RedisSyncCache(redisTemplate, dataProvision);
        }
        // return default cache
        return new DefaultSyncCache(dataProvision)
                .setVersionRepository(SyncContext.getBean(VersionRepository.class))
                .setBuildRepository(SyncContext.getBean(BuildRepository.class))
                .setSerialRepository(SyncContext.getBean(SerialRepository.class))
                .setMappingRepository(SyncContext.getBean(MappingRepository.class));
    }

    @Bean("syncDataSource")
    @Qualifier("syncDataSource")
    public SyncDataSource getSyncDataSource() {
        SyncDataSource dataSource = new SyncDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }
}
