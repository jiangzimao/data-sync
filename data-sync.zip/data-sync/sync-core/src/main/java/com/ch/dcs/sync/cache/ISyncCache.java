package com.ch.dcs.sync.cache;

import com.ch.dcs.sync.api.mode.VersionType;
import com.ch.dcs.sync.entity.VersionEntity;

import java.util.List;
import java.util.Set;

public interface ISyncCache {

    String getBuildId(String versionId, VersionType versionType, Boolean init);

    Double getMinVersion(VersionType versionType, String buildId, String versionId);

    Double getMaxVersion(VersionType versionType, String buildId, String versionId);

    Double getNextVersion(String versionKey);

    void saveVersionEntity(VersionEntity entity);

    VersionEntity getVersionEntity(String entityKey);

    List<VersionEntity> sub(String sortedKey, Double start, Boolean includeStart, Double end, Boolean includeEnd);

    Double getVersion(String sortedKey, String bizKey);

    void createBuildId(String versionId, String buildId, VersionType versionType);

    List<VersionEntity> findAllByType(VersionType type);

    Boolean updateTypeByBizKey(String entityKey, VersionType server);
}
