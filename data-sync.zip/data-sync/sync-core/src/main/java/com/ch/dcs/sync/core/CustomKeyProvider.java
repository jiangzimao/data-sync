package com.ch.dcs.sync.core;

public abstract class CustomKeyProvider<T> {

    protected T defaultCustomKeys;

    protected CustomKeyProvider(T defaultCustomKeys) {
        this.defaultCustomKeys = defaultCustomKeys;
    }

    public T getDefaultCustomKeys() {
        return defaultCustomKeys;
    }

    public abstract T getCustomKeys();

}
