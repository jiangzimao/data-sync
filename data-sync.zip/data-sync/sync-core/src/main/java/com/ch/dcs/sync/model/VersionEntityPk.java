package com.ch.dcs.sync.model;

import com.ch.dcs.sync.api.mode.VersionType;

import java.io.Serializable;

public class VersionEntityPk implements Serializable {

    private String buildId;
    private String bizKey;

    public VersionEntityPk() {
    }

    public VersionEntityPk(String buildId, String bizKey) {
        this.buildId = buildId;
        this.bizKey = bizKey;
    }

    public String getBuildId() {
        return buildId;
    }

    public void setBuildId(String buildId) {
        this.buildId = buildId;
    }

    public String getBizKey() {
        return bizKey;
    }

    public void setBizKey(String bizKey) {
        this.bizKey = bizKey;
    }
}
