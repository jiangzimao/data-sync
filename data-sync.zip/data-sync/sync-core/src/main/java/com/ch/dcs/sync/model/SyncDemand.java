package com.ch.dcs.sync.model;

import com.ch.dcs.sync.core.EntityFilter;

import java.io.Serializable;

public class SyncDemand implements Serializable {

    private String buildId;
    private String versionName;
    private String customKey;
    private Double local;
    private Double submit;
    private EntityFilter entityFilter;

    public SyncDemand() {
    }

    public SyncDemand(String buildId, String versionName, String customKey) {
        this.buildId = buildId;
        this.versionName = versionName;
        this.customKey = customKey;
    }

    public String getBuildId() {
        return buildId;
    }

    public void setBuildId(String buildId) {
        this.buildId = buildId;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public String getCustomKey() {
        return customKey;
    }

    public void setCustomKey(String customKey) {
        this.customKey = customKey;
    }

    public Double getLocal() {
        return local;
    }

    public void setLocal(Double local) {
        this.local = local;
    }

    public Double getSubmit() {
        return submit;
    }

    public void setSubmit(Double submit) {
        this.submit = submit;
    }

    public EntityFilter getEntityFilter() {
        return entityFilter;
    }

    public void setEntityFilter(EntityFilter entityFilter) {
        this.entityFilter = entityFilter;
    }

    @Override
    public String toString() {
        return "SyncDemand{" +
                "buildId='" + buildId + '\'' +
                ", versionName='" + versionName + '\'' +
                ", customKey='" + customKey + '\'' +
                ", local=" + local +
                ", submit=" + submit +
                '}';
    }
}
