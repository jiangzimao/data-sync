package com.ch.dcs.sync.core;

import com.ch.dcs.sync.api.mode.VersionData;
import com.ch.dcs.sync.model.SyncMessage;
import com.ch.dcs.sync.model.PullRequest;
import com.ch.dcs.sync.model.VersionEntities;
import com.ch.dcs.sync.service.IVersionService;
import com.ch.dcs.sync.util.KryoUtil;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Aspect
@Component
public class CheckDataAop {

    private static final Logger LOG = LoggerFactory.getLogger(CheckDataAop.class);

    @Around(value = "@annotation(requestMapping)")
    public Object checkData(ProceedingJoinPoint point, RequestMapping requestMapping) throws Throwable {
        long startTime = System.currentTimeMillis();
        long postTime;
        long checkTime;
        long kryoTime;
        IVersionService versionService = SyncContext.getBean(IVersionService.class);
        Object proceedResult = point.proceed(point.getArgs());
        if(proceedResult instanceof SyncMessage) {
            SyncMessage syncMessage = (SyncMessage) proceedResult;
            postTime = System.currentTimeMillis() - startTime;
            startTime = System.currentTimeMillis();
            RequestMethod[] methods = requestMapping.method();
            Boolean isPost = Arrays.stream(methods).anyMatch(method -> method.equals(RequestMethod.POST));
            isPost = isPost && !"push".equalsIgnoreCase(requestMapping.name()) && !"pull".equalsIgnoreCase(requestMapping.name());
            if(isPost) {
                try {
                    ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
                    HttpServletRequest request = servletRequestAttributes.getRequest();
                    // 获取请求版本信息
                    String checkVersion = request.getHeader("Check-Version");
                    if (StringUtils.isNotBlank(checkVersion)) {
                        PullRequest versionRequest = KryoUtil.readObjectFromString(checkVersion, PullRequest.class);
                        List<VersionData> versionDataList = versionService.pull(versionRequest.getDemands(), -1L);
                        checkTime = System.currentTimeMillis() - startTime;
                        startTime = System.currentTimeMillis();
                        VersionEntities versionResponse = new VersionEntities(versionDataList);
                        String versionData = KryoUtil.writeObjectToString(versionResponse);
                        syncMessage.setVersionData(versionData);
                        kryoTime = System.currentTimeMillis() - startTime;
                        LOG.info(String.format("request finish postTime:%s ms, checkTime: %s ms, kryoTime: %s ms", postTime, checkTime, kryoTime));
                    }
                } catch (Exception e) {
                    LOG.error("check data error. ", e);
                }
                return syncMessage;
            }
        }
        return proceedResult;
    }

}
