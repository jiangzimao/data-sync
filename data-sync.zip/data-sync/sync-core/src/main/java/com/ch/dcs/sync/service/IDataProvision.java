package com.ch.dcs.sync.service;

import java.util.List;
import java.util.Set;

/**
 * Providing business data interface
 */
public interface IDataProvision {

    /**
     * Getting business entity based on key
     *
     * @param key business entity key
     * @return entity
     */
    <T> T getBizEntityByKey(String key, Set<Class<?>> classSet);

    /**
     * find biz entities from interface
     *
     * @param typeVersionValue  value of the type annotation VersionAble
     * @param fieldVersionValue value of the field annotation VersionAble
     * @return bizEntities
     */
    <T> List<T> findEntities(String typeVersionValue, String fieldVersionValue);
}
