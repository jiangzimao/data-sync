package com.ch.dcs.sync.model;

import com.ch.dcs.sync.ex.SyncException;
import com.ch.dcs.sync.util.ClassUtil;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class VersionMapping {

    private String key;
    private final Map<Class<?>, Set<String>> exclusionFieldMapping = new ConcurrentHashMap<>();
    private final Map<Class<?>, Field> bizKeyMapping = new ConcurrentHashMap<>();
    private final Map<Class<?>, Field> customKeyMapping = new ConcurrentHashMap<>();

    private VersionMapping() {
    }

    public VersionMapping(String key) {
        this();
        this.key = key;
    }

    public void addClass(Class<?> cla, String bizKey, String... exclusionFields) {
        Set<String> exclusionFieldSet;
        if(exclusionFields != null && exclusionFields.length > 0) {
            exclusionFieldSet = Arrays.stream(exclusionFields).collect(Collectors.toSet());
        } else {
            exclusionFieldSet = new HashSet<>();
        }
        exclusionFieldMapping.put(cla, exclusionFieldSet);
        Field bizKeyField = ClassUtil.getField(cla, bizKey);
        if(bizKeyField != null) {
            bizKeyField.setAccessible(Boolean.TRUE);
            bizKeyMapping.put(cla, bizKeyField);
        } else {
            throw new SyncException(String.format("the %s not bind bizKey field", cla.getSimpleName()));
        }
    }

    public void addField(Class<?> cla, String customKey, String bizKey, String... exclusionFields){
        Field customKeyField = ClassUtil.getField(cla, customKey);
        if(customKeyField == null) {
            throw new SyncException(String.format("not find field %s on the class %s", customKey, cla.getSimpleName()));
        }
        customKeyField.setAccessible(Boolean.TRUE);
        customKeyMapping.put(cla, customKeyField);
        addClass(cla, bizKey, exclusionFields);
    }

    public String getKey() {
        return key;
    }

    public Set<String> getExclusionFields(Class<?> cla) {
        return exclusionFieldMapping.get(cla);
    }

    public Map<Class<?>, Field> getBizKeyMapping() {
        return bizKeyMapping;
    }

    public Field getCustomKeyField(Class<?> cla) {
        return customKeyMapping.get(cla);
    }
}
