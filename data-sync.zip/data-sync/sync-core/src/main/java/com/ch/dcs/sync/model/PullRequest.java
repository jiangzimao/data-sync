package com.ch.dcs.sync.model;

import java.io.Serializable;
import java.util.List;

public class PullRequest implements Serializable {

    private List<SyncDemand> demands;

    public PullRequest() {
    }

    public PullRequest(List<SyncDemand> demands) {
        this.demands = demands;
    }

    public List<SyncDemand> getDemands() {
        return demands;
    }

    public void setDemands(List<SyncDemand> demands) {
        this.demands = demands;
    }
}
