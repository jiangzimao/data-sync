package com.ch.dcs.sync.util;

import com.ch.dcs.sync.core.SyncContext;
import com.ch.dcs.sync.ex.SyncException;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public abstract class JvmLock {

    private static Cache<String, ReentrantLock> locks = CacheBuilder.newBuilder().expireAfterAccess(5, TimeUnit.MINUTES).build();

    public static Boolean tryLock(String key, long timeout, TimeUnit timeUnit) {
        try {
            ReentrantLock lock = locks.get(key, () -> new ReentrantLock(true));
            // if(lock.isLocked()) {
            //     System.out.println(String.format("%s key[%s] ls lock :%s", Thread.currentThread().getName(), key, lock));
            // }
            Long startTime = System.currentTimeMillis();
            if (lock.tryLock(timeout, timeUnit)) {
                return true;
            } else {
                throw new SyncException(String.format("try java lock key[%s] result is false. time %s ms",
                        key, (System.currentTimeMillis() - startTime)));
            }
        } catch (Throwable e) {
            throw new SyncException(String.format("try lock key[%s] error.", key), e);
        }
    }

    public static void unLock(String key) {
        ReentrantLock lock = locks.getIfPresent(key);
        if(lock != null) {
            lock.unlock();
        } else {
            locks.invalidate(key);
        }
    }

    private static String getLockKey(String key) {
        return String.format("%s:lock:lock_%s", SyncContext.getRedisPrefix(), key);
    }

}
