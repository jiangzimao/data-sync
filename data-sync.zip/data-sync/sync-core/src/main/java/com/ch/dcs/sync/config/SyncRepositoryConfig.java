package com.ch.dcs.sync.config;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.sql.DataSource;

import com.ch.dcs.sync.repository.BuildRepository;
import com.ch.dcs.sync.repository.MappingRepository;
import com.ch.dcs.sync.repository.SerialRepository;
import com.ch.dcs.sync.repository.VersionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackageClasses = {VersionRepository.class, SerialRepository.class, MappingRepository.class, BuildRepository.class},
        entityManagerFactoryRef="syncEntityManagerFactory",
        transactionManagerRef="syncTransactionManager")
public class SyncRepositoryConfig {

    @Resource
    private JpaProperties jpaProperties;

    @Autowired @Qualifier("syncDataSource")
    private DataSource syncDataSource;

    @Bean(name = "syncEntityManager")
    public EntityManager syncEntityManager(EntityManagerFactoryBuilder builder) {
        return syncEntityManagerFactory(builder).getObject().createEntityManager();
    }

    @Bean(name = "syncEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean syncEntityManagerFactory (EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(syncDataSource)
                .properties(jpaProperties.getHibernateProperties(syncDataSource))
                .packages("com.ch.dcs.sync.entity")
                .persistenceUnit("syncPersistenceUnit")
                .build();
    }

    @Bean(name = "syncTransactionManager")
    public PlatformTransactionManager syncTransactionManager(EntityManagerFactoryBuilder builder) {
        return new JpaTransactionManager(syncEntityManagerFactory(builder).getObject());
    }

}
